/**
 * Zero-network image placeholder. Renders a styled gradient div instead of
 * an <img> so Figma Make's preview never times out waiting for external URLs.
 * Each src string hashes to a distinct gradient + emoji so placeholders look
 * intentional and varied rather than generic grey boxes.
 */

import type { CSSProperties } from 'react'

const GRADIENTS = [
  'linear-gradient(135deg, #e8f5ee 0%, #a7f3d0 100%)',
  'linear-gradient(135deg, #fef3e2 0%, #fcd6a4 100%)',
  'linear-gradient(135deg, #f5f0ff 0%, #ddd6fe 100%)',
  'linear-gradient(135deg, #fee2e2 0%, #fca5a5 100%)',
  'linear-gradient(135deg, #e0f2fe 0%, #7dd3fc 100%)',
  'linear-gradient(135deg, #fef9e7 0%, #fde68a 100%)',
  'linear-gradient(135deg, #f0fdf4 0%, #86efac 100%)',
  'linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%)',
  'linear-gradient(135deg, #ecfdf5 0%, #6ee7b7 100%)',
  'linear-gradient(135deg, #fdf2f8 0%, #f0abfc 100%)',
]

const EMOJIS: Record<string, string> = {
  mango: '🥭', mangoes: '🥭', fruit: '🍎', apple: '🍎',
  yogurt: '🥛', dairy: '🥛', milk: '🥛', egg: '🥚', eggs: '🥚',
  spinach: '🥬', vegetable: '🥬', produce: '🥦', tomato: '🍅',
  juice: '🧃', orange: '🍊', beverage: '🥤', drink: '🧃',
  bread: '🍞', bakery: '🥐', sourdough: '🍞',
  salmon: '🐟', fish: '🐟', seafood: '🐟',
  matcha: '🍵', tea: '🍵', coffee: '☕',
  cheese: '🧀', avocado: '🥑',
  chocolate: '🍫', snack: '🍪',
  coconut: '🥥', oat: '🥣', berry: '🫐',
  store: '🏪', market: '🛒', grocery: '🛒',
  profile: '👤', person: '👤', user: '👤',
  banner: '🌿', hero: '🌟', sale: '⚡', fresh: '🌿',
  meal: '🍽', food: '🍽', recipe: '👨‍🍳',
}

function hashStr(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}

function pickEmoji(alt: string, src: string): string {
  const needle = (alt + ' ' + src).toLowerCase()
  for (const [key, emoji] of Object.entries(EMOJIS)) {
    if (needle.includes(key)) return emoji
  }
  return '🌿'
}

interface ImgProps {
  src: string
  alt: string
  style?: CSSProperties
  className?: string
}

export default function Img({ src, alt, style, className }: ImgProps) {
  const h = hashStr(src)
  const gradient = GRADIENTS[h % GRADIENTS.length]
  const emoji = pickEmoji(alt, src)

  return (
    <div
      className={className}
      style={{
        background: gradient,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '2em',
        ...style,
      }}
      aria-label={alt}
      role="img"
    >
      {emoji}
    </div>
  )
}
