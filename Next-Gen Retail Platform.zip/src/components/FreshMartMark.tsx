/**
 * FreshMart brand mark — "F-sprout"
 *
 * The two horizontal bars of the letterform F are replaced by geometric leaf
 * shapes growing rightward from a vertical stem. At small scale it reads as
 * the brand initial; at large scale the double-leaf sprout read becomes clear.
 *
 * Geometry is constructed on a 100×100 grid. The stem sits left of
 * mathematical centre (x=40) so the leaves can extend right without the mark
 * feeling heavy-left when set alongside the wordmark.
 */

interface MarkProps {
  /** Foreground fill — white by default (designed for dark grounds) */
  color?: string
  size?: number
  className?: string
}

export function FreshMartMark({ color = '#ffffff', size = 100, className }: MarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="FreshMart mark"
    >
      {/* Stem — tapered slightly at top, giving the mark a calligraphic root */}
      <path
        d="M 37 82 C 37 82 36.5 42 37.5 22 C 38.5 18 41.5 18 42.5 22 C 43.5 42 43 82 43 82 Z"
        fill={color}
      />

      {/* Bud — small rounded tip at the top of the stem, signals growth */}
      <circle cx="40" cy="17" r="5.5" fill={color} />

      {/* Top leaf — corresponds to F's upper bar; extends to x=77, angled 5° upward */}
      <path
        d="M 43 27 C 53 17 70 15 77 21 C 69 25 53 33 43 33 Z"
        fill={color}
      />

      {/* Middle leaf — corresponds to F's lower bar; shorter, 2/3 the width of top leaf */}
      <path
        d="M 43 48 C 51 40 66 39 71 45 C 64 49 51 56 43 55 Z"
        fill={color}
      />
    </svg>
  )
}

interface LogoProps {
  /** 'light' = mark on white/light grounds; 'dark' = mark+text on dark grounds */
  variant?: 'light' | 'dark' | 'green'
  height?: number
}

export function FreshMartLogo({ variant = 'light', height = 40 }: LogoProps) {
  const markColor =
    variant === 'green' ? '#ffffff' :
    variant === 'dark'  ? '#f0ede6' : '#0a4f2e'

  const textColor =
    variant === 'green' ? '#ffffff' :
    variant === 'dark'  ? '#f0ede6' : '#0a4f2e'

  const accentColor =
    variant === 'green' ? 'rgba(255,255,255,0.7)' :
    variant === 'dark'  ? '#9a9480' : '#6b6455'

  // viewBox: 280×80 to fit mark + wordmark
  const scale = height / 80

  return (
    <svg
      width={280 * scale}
      height={height}
      viewBox="0 0 280 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="FreshMart"
    >
      {/* Mark at left — occupies 0–80 */}
      <g transform="translate(0, 0) scale(0.8)">
        {/* Stem */}
        <path
          d="M 37 82 C 37 82 36.5 42 37.5 22 C 38.5 18 41.5 18 42.5 22 C 43.5 42 43 82 43 82 Z"
          fill={markColor}
        />
        {/* Bud */}
        <circle cx="40" cy="17" r="5.5" fill={markColor} />
        {/* Top leaf */}
        <path
          d="M 43 27 C 53 17 70 15 77 21 C 69 25 53 33 43 33 Z"
          fill={markColor}
        />
        {/* Middle leaf */}
        <path
          d="M 43 48 C 51 40 66 39 71 45 C 64 49 51 56 43 55 Z"
          fill={markColor}
        />
      </g>

      {/* Thin divider */}
      <line x1="72" y1="18" x2="72" y2="62" stroke={markColor} strokeWidth="1" strokeOpacity="0.2" />

      {/* Wordmark — Fraunces display serif, "Fresh" regular + "Mart" italic */}
      <text
        x="82"
        y="48"
        fontFamily="'Fraunces', Georgia, serif"
        fontWeight="600"
        fontSize="34"
        fill={textColor}
        letterSpacing="-0.5"
      >
        Fresh
      </text>
      <text
        x="185"
        y="48"
        fontFamily="'Fraunces', Georgia, serif"
        fontWeight="300"
        fontStyle="italic"
        fontSize="34"
        fill={textColor}
        letterSpacing="-0.5"
      >
        mart
      </text>

      {/* Tagline */}
      <text
        x="82"
        y="62"
        fontFamily="'Inter', sans-serif"
        fontWeight="400"
        fontSize="9.5"
        fill={accentColor}
        letterSpacing="2"
      >
        PREMIUM HYPERMARKET
      </text>
    </svg>
  )
}

interface IconProps {
  /** Overall pixel size of the icon tile */
  size?: number
  /** Corner radius as a proportion of size (0–0.5). Defaults to iOS-style 0.225 */
  radiusRatio?: number
}

/** Square app-icon tile — transparent SVG with the tile rect + mark inside */
export function FreshMartIcon({ size = 120, radiusRatio = 0.225 }: IconProps) {
  const r = size * radiusRatio

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="FreshMart app icon"
    >
      {/* Tile background — deep forest green with subtle gradient */}
      <defs>
        <linearGradient id="iconBg" x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0d5c38" />
          <stop offset="100%" stopColor="#073d25" />
        </linearGradient>
        {/* Soft inner glow on the mark */}
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      <rect width="120" height="120" rx={r} fill="url(#iconBg)" />

      {/* Subtle texture ring */}
      <rect
        width="120" height="120" rx={r}
        fill="none"
        stroke="rgba(255,255,255,0.06)"
        strokeWidth="1"
      />

      {/* Gold accent band — subtle stripe at top right */}
      <path
        d="M 80 0 Q 120 0 120 40 L 120 0 Z"
        fill="rgba(201,153,26,0.18)"
      />

      {/* Mark — centered, scaled to ~60% of tile width */}
      {/* Translate so the visual centre of the mark (approx x=56, y=50 in 100px grid) lands at (60,62) */}
      <g transform="translate(8, 8) scale(1.04)" filter="url(#glow)">
        {/* Stem */}
        <path
          d="M 37 82 C 37 82 36.5 42 37.5 22 C 38.5 18 41.5 18 42.5 22 C 43.5 42 43 82 43 82 Z"
          fill="white"
        />
        {/* Bud */}
        <circle cx="40" cy="17" r="5.5" fill="white" />
        {/* Top leaf */}
        <path d="M 43 27 C 53 17 70 15 77 21 C 69 25 53 33 43 33 Z" fill="white" />
        {/* Middle leaf */}
        <path d="M 43 48 C 51 40 66 39 71 45 C 64 49 51 56 43 55 Z" fill="white" />
      </g>

      {/* "FM" micro-label at bottom centre — visible at larger sizes */}
      <text
        x="60"
        y="108"
        fontFamily="'Inter', sans-serif"
        fontSize="7"
        fontWeight="600"
        letterSpacing="2"
        fill="rgba(255,255,255,0.35)"
        textAnchor="middle"
      >
        FRESHMART
      </text>
    </svg>
  )
}
