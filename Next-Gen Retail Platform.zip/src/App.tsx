import { useState, useEffect, useRef } from 'react'
import HomeScreen from './screens/HomeScreen'
import ShopScreen from './screens/ShopScreen'
import CartScreen from './screens/CartScreen'
import LoyaltyScreen from './screens/LoyaltyScreen'
import AccountScreen from './screens/AccountScreen'
import AdminScreen from './screens/AdminScreen'
import ProductScreen from './screens/ProductScreen'
import OrdersScreen from './screens/OrdersScreen'
import BrandScreen from './screens/BrandScreen'
import { FreshMartLogo, FreshMartIcon } from './components/FreshMartMark'
import { type CartItem, type Product } from './data/types'
import { PRODUCTS } from './data/products'

export type Screen = 'home' | 'shop' | 'cart' | 'loyalty' | 'account' | 'admin' | 'product' | 'orders' | 'brand'

export default function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [prevScreen, setPrevScreen] = useState<Screen>('home')
  const [cart, setCart] = useState<CartItem[]>([])
  const [wishlist, setWishlist] = useState<number[]>([12, 7])
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isDark, setIsDark] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [showAdminBanner, setShowAdminBanner] = useState(true)
  const screenRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [isDark])

  useEffect(() => {
    screenRef.current?.scrollTo(0, 0)
  }, [screen])

  const navigate = (s: Screen) => {
    setPrevScreen(screen)
    setScreen(s)
  }

  const openProduct = (product: Product) => {
    setSelectedProduct(product)
    navigate('product')
  }

  const addToCart = (product: Product, qty = 1) => {
    setCart(prev => {
      const existing = prev.find(i => i.product.id === product.id)
      if (existing) {
        return prev.map(i => i.product.id === product.id ? { ...i, qty: i.qty + qty } : i)
      }
      return [...prev, { product, qty }]
    })
  }

  const updateCartQty = (productId: number, qty: number) => {
    if (qty <= 0) {
      setCart(prev => prev.filter(i => i.product.id !== productId))
    } else {
      setCart(prev => prev.map(i => i.product.id === productId ? { ...i, qty } : i))
    }
  }

  const toggleWishlist = (productId: number) => {
    setWishlist(prev => prev.includes(productId)
      ? prev.filter(id => id !== productId)
      : [...prev, productId]
    )
  }

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0)
  const cartTotal = cart.reduce((sum, i) => sum + i.product.price * i.qty, 0)

  const tabs = [
    { id: 'home' as Screen, icon: HomeIcon, label: 'Home' },
    { id: 'shop' as Screen, icon: ShopIcon, label: 'Shop' },
    { id: 'cart' as Screen, icon: CartIcon, label: 'Cart', badge: cartCount },
    { id: 'loyalty' as Screen, icon: StarIcon, label: 'Rewards' },
    { id: 'account' as Screen, icon: PersonIcon, label: 'Account' },
  ]

  const screenProps = {
    navigate,
    openProduct,
    addToCart,
    toggleWishlist,
    wishlist,
    cart,
    isDark,
    setIsDark,
    searchQuery,
    setSearchQuery,
  }

  return (
    <div
      style={{ minHeight: '100vh', background: isDark ? '#0a1a0e' : '#e8e3d9' }}
      className="flex items-center justify-center p-8"
    >
      {/* Desktop ambient UI */}
      <div className="hidden lg:flex flex-col items-center gap-6 mr-8 w-48">
        <button onClick={() => navigate('brand')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <FreshMartLogo variant={isDark ? 'dark' : 'light'} height={28} />
        </button>
        {showAdminBanner && (
          <div
            className="w-full rounded-xl p-3 cursor-pointer text-xs"
            style={{ background: '#0a4f2e', color: '#fff' }}
            onClick={() => { navigate('admin'); setShowAdminBanner(false) }}
          >
            <div className="font-semibold mb-1">Admin Dashboard</div>
            <div style={{ color: 'rgba(255,255,255,0.7)' }}>View analytics & manage inventory →</div>
          </div>
        )}
        <div className="w-full rounded-xl p-3 text-xs" style={{ background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)', color: isDark ? '#9a9480' : '#6b6455' }}>
          <div className="font-semibold mb-2" style={{ color: isDark ? '#f0ede6' : '#14110e' }}>Quick Nav</div>
          {(['home','shop','cart','loyalty','account','orders','brand'] as Screen[]).map(s => (
            <button
              key={s}
              onClick={() => navigate(s)}
              className="block w-full text-left py-1 capitalize hover:opacity-80 transition-opacity"
              style={{ color: screen === s ? '#0a4f2e' : undefined, fontWeight: screen === s ? '600' : '400' }}
            >
              {s === 'orders' ? 'Orders' : s === 'brand' ? 'Brand Assets' : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Phone shell */}
      <div className="phone-shell" style={{ background: isDark ? '#0f1a13' : '#f7f6f2' }}>
        {/* Phone notch */}
        <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: 126, height: 34, background: '#000', borderRadius: '0 0 20px 20px', zIndex: 200 }} />
        {/* App icon in top-right corner of phone shell */}
        <div style={{ position: 'absolute', top: 8, right: 12, zIndex: 201 }}>
          <FreshMartIcon size={20} radiusRatio={0.3} />
        </div>

        {/* Screen content */}
        <div ref={screenRef} className="phone-screen" style={{ paddingBottom: screen === 'admin' ? 0 : 80 }}>
          <div className="screen-enter" key={screen}>
            {screen === 'home' && (
              <HomeScreen {...screenProps} />
            )}
            {screen === 'shop' && (
              <ShopScreen {...screenProps} />
            )}
            {screen === 'cart' && (
              <CartScreen {...screenProps} cart={cart} updateCartQty={updateCartQty} cartTotal={cartTotal} />
            )}
            {screen === 'loyalty' && (
              <LoyaltyScreen {...screenProps} cartTotal={cartTotal} />
            )}
            {screen === 'account' && (
              <AccountScreen {...screenProps} />
            )}
            {screen === 'admin' && (
              <AdminScreen navigate={navigate} isDark={isDark} setIsDark={setIsDark} />
            )}
            {screen === 'product' && selectedProduct && (
              <ProductScreen
                {...screenProps}
                product={selectedProduct}
                inCart={cart.find(i => i.product.id === selectedProduct.id)?.qty || 0}
                back={() => navigate(prevScreen === 'product' ? 'shop' : prevScreen)}
              />
            )}
            {screen === 'orders' && (
              <OrdersScreen navigate={navigate} />
            )}
            {screen === 'brand' && (
              <BrandScreen navigate={navigate} />
            )}
          </div>
        </div>

        {/* Bottom tab bar — hidden on admin and product screens */}
        {screen !== 'admin' && (
          <div className="tab-bar">
            {tabs.map(tab => {
              const Icon = tab.icon
              const active = screen === tab.id || (screen === 'product' && tab.id === 'shop') || (screen === 'orders' && tab.id === 'account')
              return (
                <button
                  key={tab.id}
                  onClick={() => navigate(tab.id)}
                  className="flex flex-col items-center gap-0.5 relative"
                  style={{ minWidth: 48 }}
                >
                  <div className="relative">
                    <Icon size={22} color={active ? '#0a4f2e' : (isDark ? '#9a9480' : '#9a9075')} />
                    {tab.badge ? (
                      <span className="badge-pop absolute -top-1 -right-1 min-w-4 h-4 rounded-full text-white flex items-center justify-center font-semibold" style={{ fontSize: 9, background: '#dc2626', padding: '0 3px' }}>
                        {tab.badge > 99 ? '99+' : tab.badge}
                      </span>
                    ) : null}
                  </div>
                  <span style={{ fontSize: 9.5, fontWeight: active ? 600 : 400, color: active ? '#0a4f2e' : (isDark ? '#9a9480' : '#9a9075') }}>
                    {tab.label}
                  </span>
                  {active && (
                    <span style={{ position: 'absolute', bottom: -12, left: '50%', transform: 'translateX(-50%)', width: 4, height: 4, borderRadius: 2, background: '#0a4f2e' }} />
                  )}
                </button>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// --- Icon components ---
function HomeIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 12L12 3L21 12V21H15V15H9V21H3V12Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" fill="none" />
    </svg>
  )
}
function ShopIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="7" width="18" height="14" rx="2" stroke={color} strokeWidth="1.8" />
      <path d="M8 7C8 4.79 9.79 3 12 3C14.21 3 16 4.79 16 7" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}
function CartIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M6 2L3 6V20C3 21.1 3.9 22 5 22H19C20.1 22 21 21.1 21 20V6L18 2H6Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
      <path d="M3 6H21" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <path d="M16 10C16 12.21 14.21 14 12 14C9.79 14 8 12.21 8 10" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}
function StarIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  )
}
function PersonIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.8" />
      <path d="M4 20C4 16.69 7.58 14 12 14C16.42 14 20 16.69 20 20" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}
