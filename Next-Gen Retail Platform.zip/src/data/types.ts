export interface Product {
  id: number
  name: string
  brand: string
  category: string
  subcategory: string
  price: number
  originalPrice?: number
  unit: string
  image: string
  rating: number
  reviewCount: number
  inStock: boolean
  stockQty?: number
  badge?: string
  badgeColor?: string
  description: string
  tags: string[]
  isOrganic?: boolean
  isNew?: boolean
  isTrending?: boolean
}

export interface CartItem {
  product: Product
  qty: number
}

export interface Order {
  id: string
  date: string
  status: 'delivered' | 'out_for_delivery' | 'processing' | 'cancelled'
  items: { name: string; qty: number; price: number }[]
  total: number
  deliveryAddress: string
}
