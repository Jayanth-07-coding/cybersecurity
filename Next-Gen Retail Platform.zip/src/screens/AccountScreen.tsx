import { useState } from 'react'
import Img from '../components/Img'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  isDark: boolean
  setIsDark: (v: boolean) => void
}

type MenuItem = { icon: string; label: string; badge?: string; target?: Screen }

const MENU_SECTIONS: { title: string; items: MenuItem[] }[] = [
  {
    title: 'Shopping',
    items: [
      { icon: '📦', label: 'My Orders', badge: '2 active', target: 'orders' },
      { icon: '❤️', label: 'Wishlist', badge: '12 items', target: 'shop' },
      { icon: '🔄', label: 'Reorder Favourites', target: 'orders' },
      { icon: '📋', label: 'Shopping Lists', target: 'loyalty' },
      { icon: '💊', label: 'Subscription Orders', target: 'orders' },
    ],
  },
  {
    title: 'Account',
    items: [
      { icon: '🏠', label: 'Saved Addresses' },
      { icon: '💳', label: 'Payment Methods' },
      { icon: '🔔', label: 'Notifications' },
      { icon: '👨‍👩‍👧', label: 'Family Accounts' },
    ],
  },
  {
    title: 'Preferences',
    items: [
      { icon: '🥗', label: 'Dietary Preferences' },
      { icon: '🌿', label: 'Eco-Friendly Filters', target: 'shop' },
      { icon: '💰', label: 'Budget Mode' },
      { icon: '🌐', label: 'Language & Region' },
    ],
  },
  {
    title: 'Support',
    items: [
      { icon: '💬', label: 'Chat Support' },
      { icon: '📞', label: 'Call Us: 1800-123-4567' },
      { icon: '❓', label: 'FAQ' },
      { icon: '⭐', label: 'Rate the App' },
      { icon: '📤', label: 'Share FreshMart' },
    ],
  },
]

export default function AccountScreen({ navigate, isDark, setIsDark }: Props) {
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false)

  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Profile header */}
      <div style={{ padding: '0 20px 20px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: text, marginBottom: 16 }}>My Account</div>

        <div style={{ borderRadius: 20, background: cardBg, padding: '16px', display: 'flex', gap: 14, alignItems: 'center' }}>
          <div style={{ position: 'relative' }}>
            <div style={{ width: 60, height: 60, borderRadius: 18, overflow: 'hidden', border: '3px solid #c9991a' }}>
              <Img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&auto=format" alt="Priya" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            <div style={{ position: 'absolute', bottom: -2, right: -2, width: 18, height: 18, borderRadius: 6, background: '#0a4f2e', border: `2px solid ${cardBg}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9 }}>✏️</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: text, marginBottom: 2 }}>Priya Sharma</div>
            <div style={{ fontSize: 12, color: muted, marginBottom: 6 }}>priya.sharma@gmail.com · +91 98765 43210</div>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ fontSize: 10, background: '#fef9e7', color: '#c9991a', padding: '2px 8px', borderRadius: 6, fontWeight: 700 }}>🥇 Gold Member</span>
              <span style={{ fontSize: 10, background: '#e8f5ee', color: '#0a4f2e', padding: '2px 8px', borderRadius: 6, fontWeight: 600 }}>2,840 pts</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dark mode toggle + admin shortcut */}
      <div style={{ padding: '0 20px 16px', display: 'flex', gap: 12 }}>
        <div style={{ flex: 1, borderRadius: 16, background: cardBg, padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 18 }}>{isDark ? '🌙' : '☀️'}</span>
            <span style={{ fontSize: 13, fontWeight: 500, color: text }}>{isDark ? 'Dark' : 'Light'} Mode</span>
          </div>
          <button onClick={() => setIsDark(!isDark)}
            style={{ width: 44, height: 24, borderRadius: 12, background: isDark ? '#0a4f2e' : '#e4e0d8', position: 'relative', border: 'none', cursor: 'pointer', transition: 'background 0.2s' }}
          >
            <div style={{ position: 'absolute', top: 3, left: isDark ? 22 : 3, width: 18, height: 18, borderRadius: 9, background: isDark ? '#fff' : '#6b6455', transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
          </button>
        </div>
        <button onClick={() => navigate('admin')}
          style={{ flex: 1, borderRadius: 16, background: '#0a4f2e', padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 8, border: 'none', cursor: 'pointer' }}
        >
          <span style={{ fontSize: 18 }}>📊</span>
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#fff' }}>Admin</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)' }}>Dashboard</div>
          </div>
        </button>
      </div>

      {/* Quick stats */}
      <div style={{ margin: '0 20px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
        {[
          { label: 'Orders', value: '47', icon: '📦' },
          { label: 'Reviews', value: '12', icon: '⭐' },
          { label: 'Saved', value: '₹3,240', icon: '💰' },
        ].map(stat => (
          <div key={stat.label} style={{ borderRadius: 16, background: cardBg, padding: '12px', textAlign: 'center' }}>
            <div style={{ fontSize: 20, marginBottom: 4 }}>{stat.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: '#0a4f2e', marginBottom: 2 }}>{stat.value}</div>
            <div style={{ fontSize: 10.5, color: muted }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Menu sections */}
      {MENU_SECTIONS.map(section => (
        <div key={section.title} style={{ margin: '0 20px 16px' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: muted, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 }}>{section.title}</div>
          <div style={{ borderRadius: 16, background: cardBg, overflow: 'hidden' }}>
            {section.items.map((item, i) => (
              <button
                key={item.label}
                onClick={() => item.target && navigate(item.target)}
                style={{ width: '100%', padding: '13px 16px', display: 'flex', alignItems: 'center', gap: 12, background: 'none', border: 'none', borderBottom: i < section.items.length - 1 ? `1px solid ${border}` : 'none', cursor: item.target ? 'pointer' : 'default', textAlign: 'left' }}
              >
                <span style={{ fontSize: 17, width: 24, textAlign: 'center' }}>{item.icon}</span>
                <span style={{ flex: 1, fontSize: 13, color: text, fontWeight: 400 }}>{item.label}</span>
                {item.badge && <span style={{ fontSize: 10, color: '#fff', background: '#0a4f2e', padding: '2px 7px', borderRadius: 10, fontWeight: 600 }}>{item.badge}</span>}
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke={muted} strokeWidth="1.8" strokeLinecap="round"/></svg>
              </button>
            ))}
          </div>
        </div>
      ))}

      {/* Store info */}
      <div style={{ margin: '0 20px 20px', borderRadius: 16, background: cardBg, overflow: 'hidden' }}>
        <div style={{ height: 100, overflow: 'hidden', position: 'relative' }}>
          <Img src="https://images.unsplash.com/photo-1534723452862-4c874018d66d?w=600&h=200&fit=crop&auto=format" alt="Store" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,79,46,0.7)' }} />
          <div style={{ position: 'absolute', inset: 0, padding: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: '#fff' }}>FreshMart HSR Layout</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.8)' }}>Open · 7 AM – 10 PM · 1.2 km away</div>
            </div>
            <button onClick={() => window.open('https://maps.google.com/?q=HSR+Layout+Bangalore', '_blank')} style={{ padding: '6px 14px', borderRadius: 10, background: '#fff', color: '#0a4f2e', fontSize: 11, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Navigate</button>
          </div>
        </div>
        <div style={{ padding: '12px 16px', display: 'flex', gap: 16 }}>
          <button onClick={() => window.open('https://maps.google.com/?q=FreshMart+HSR+Layout', '_blank')} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer' }}>
            <span style={{ fontSize: 14 }}>📍</span>
            <span style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 500 }}>Get Directions</span>
          </button>
          <button onClick={() => window.open('tel:18001234567')} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer' }}>
            <span style={{ fontSize: 14 }}>📞</span>
            <span style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 500 }}>Call Store</span>
          </button>
          <button onClick={() => navigate('shop')} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer' }}>
            <span style={{ fontSize: 14 }}>🗺</span>
            <span style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 500 }}>Find Aisle</span>
          </button>
        </div>
      </div>

      {/* Sign out */}
      <div style={{ padding: '0 20px 20px' }}>
        {showSignOutConfirm ? (
          <div style={{ borderRadius: 16, background: '#fff', border: '1.5px solid #fecaca', padding: '16px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#14110e', marginBottom: 6 }}>Sign out of FreshMart?</div>
            <div style={{ fontSize: 12, color: '#6b6455', marginBottom: 14 }}>You'll need to log in again to access your account.</div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setShowSignOutConfirm(false)} style={{ flex: 1, padding: '10px', borderRadius: 10, background: '#f7f6f2', color: '#14110e', fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer' }}>Cancel</button>
              <button onClick={() => { setShowSignOutConfirm(false); navigate('home') }} style={{ flex: 1, padding: '10px', borderRadius: 10, background: '#dc2626', color: '#fff', fontSize: 13, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Sign Out</button>
            </div>
          </div>
        ) : (
          <button onClick={() => setShowSignOutConfirm(true)} style={{ width: '100%', padding: '14px', borderRadius: 16, background: 'transparent', color: '#dc2626', fontSize: 14, fontWeight: 600, border: `1.5px solid #fecaca`, cursor: 'pointer' }}>
            Sign Out
          </button>
        )}
      </div>

      <div style={{ height: 8 }} />
    </div>
  )
}
