import { useState, useEffect, useRef } from 'react'
import Img from '../components/Img'
import type { Product } from '../data/types'
import { PRODUCTS, CATEGORIES, FLASH_SALES, TRENDING, FRESH_TODAY } from '../data/products'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  openProduct: (p: Product) => void
  addToCart: (p: Product) => void
  toggleWishlist: (id: number) => void
  wishlist: number[]
  isDark: boolean
  searchQuery: string
  setSearchQuery: (q: string) => void
}

const BANNERS = [
  {
    id: 1,
    tag: 'Weekend Special',
    headline: 'Fresh Arrivals\nEvery Morning',
    sub: 'Farm-to-door in under 2 hours',
    cta: 'Shop Fresh',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&h=400&fit=crop&auto=format',
    accent: '#0a4f2e',
  },
  {
    id: 2,
    tag: 'Flash Sale — Ends in 3h 22m',
    headline: 'Up to 40% Off\nPremium Picks',
    sub: 'Curated deals across 200+ products',
    cta: 'View Deals',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop&auto=format',
    accent: '#d4821a',
  },
  {
    id: 3,
    tag: 'Loyalty Members Only',
    headline: '2× Points\nThis Weekend',
    sub: 'Gold & Platinum members earn double',
    cta: 'Claim Offer',
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=600&h=400&fit=crop&auto=format',
    accent: '#7c3aed',
  },
]

const QUICK_ACTIONS: { icon: string; label: string; color: string; accent: string; target: 'shop' | 'orders' | 'loyalty' | 'account' }[] = [
  { icon: '⚡', label: 'Flash Sale', color: '#fee2e2', accent: '#dc2626', target: 'shop' },
  { icon: '🔄', label: 'Reorder', color: '#e8f5ee', accent: '#0a4f2e', target: 'orders' },
  { icon: '📋', label: 'My List', color: '#f5f0ff', accent: '#7c3aed', target: 'loyalty' },
  { icon: '🏪', label: 'In-Store', color: '#fef3e2', accent: '#c2691c', target: 'account' },
]

export default function HomeScreen({ navigate, openProduct, addToCart, toggleWishlist, wishlist, isDark, searchQuery, setSearchQuery }: Props) {
  const [activeBanner, setActiveBanner] = useState(0)
  const [flashTime, setFlashTime] = useState({ h: 3, m: 22, s: 47 })
  const [addedId, setAddedId] = useState<number | null>(null)
  const bannerRef = useRef<HTMLDivElement>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveBanner(a => (a + 1) % BANNERS.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setFlashTime(t => {
        let { h, m, s } = t
        s--
        if (s < 0) { s = 59; m-- }
        if (m < 0) { m = 59; h-- }
        if (h < 0) { h = 0; m = 0; s = 0 }
        return { h, m, s }
      })
    }, 1000)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [])

  const handleAdd = (p: Product) => {
    addToCart(p)
    setAddedId(p.id)
    setTimeout(() => setAddedId(null), 1500)
  }

  const pad = (n: number) => String(n).padStart(2, '0')

  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      {/* Status bar */}
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 16px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 12, color: muted, marginBottom: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
            <span>📍</span>
            <span>Delivering to HSR Layout</span>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke={muted} strokeWidth="2" strokeLinecap="round"/></svg>
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: text, lineHeight: 1.2 }}>
            Good morning, Priya 👋
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
          <button onClick={() => navigate('account')} style={{ width: 38, height: 38, borderRadius: 12, background: cardBg, border: `1px solid ${border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke={text} strokeWidth="1.8" strokeLinecap="round"/></svg>
            <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: 4, background: '#dc2626', border: `2px solid ${bg}` }} />
          </button>
          <button onClick={() => navigate('account')} style={{ width: 38, height: 38, borderRadius: 12, overflow: 'hidden', border: `2px solid #0a4f2e`, background: 'none', padding: 0, cursor: 'pointer' }}>
            <Img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&auto=format" alt="Priya" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ position: 'relative' }}>
          <svg style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }} width="16" height="16" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="8" stroke={muted} strokeWidth="2"/>
            <path d="M21 21l-4.35-4.35" stroke={muted} strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search groceries, brands, products..."
            style={{
              width: '100%',
              padding: '11px 44px 11px 40px',
              borderRadius: 14,
              border: `1.5px solid ${border}`,
              background: cardBg,
              fontFamily: 'var(--font-body)',
              fontSize: 13,
              color: text,
              outline: 'none',
            }}
          />
          <button onClick={() => navigate('shop')} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', width: 28, height: 28, borderRadius: 8, background: '#0a4f2e', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M19 11H7.83l4.88-4.88c.39-.39.39-1.03 0-1.42-.39-.39-1.02-.39-1.41 0l-6.59 6.59c-.39.39-.39 1.02 0 1.41l6.59 6.59c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L7.83 13H19c.55 0 1-.45 1-1s-.45-1-1-1z" fill="white"/></svg>
          </button>
        </div>
      </div>

      {/* Loyalty points strip */}
      <div style={{ margin: '0 20px 16px', borderRadius: 14, background: 'linear-gradient(135deg, #0a4f2e 0%, #1a7a50 100%)', padding: '10px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }} onClick={() => navigate('loyalty')}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🏆</div>
          <div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', marginBottom: 1 }}>Gold Member · 2,840 pts</div>
            <div style={{ fontSize: 12, color: '#fff', fontWeight: 500 }}>1,160 pts to Platinum →</div>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>Expires</div>
          <div style={{ fontSize: 12, color: '#fbbf24', fontWeight: 600 }}>Dec 31</div>
        </div>
      </div>

      {/* Hero Banner Carousel */}
      <div style={{ margin: '0 20px 20px', position: 'relative', borderRadius: 18, overflow: 'hidden', height: 170, cursor: 'pointer' }}>
        {BANNERS.map((banner, i) => (
          <div
            key={banner.id}
            style={{
              position: 'absolute', inset: 0,
              opacity: activeBanner === i ? 1 : 0,
              transition: 'opacity 0.6s ease',
            }}
          >
            <Img src={banner.image} alt={banner.headline} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            <div className="banner-overlay" style={{ position: 'absolute', inset: 0 }} />
            <div style={{ position: 'absolute', inset: 0, padding: '18px 20px', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                {banner.tag.includes('Flash') && (
                  <span style={{ width: 6, height: 6, borderRadius: 3, background: '#fbbf24' }} className="pulse-dot" />
                )}
                <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>{banner.tag}</span>
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: '#fff', lineHeight: 1.2, whiteSpace: 'pre-line', marginBottom: 10 }}>
                {banner.headline}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)' }}>{banner.sub}</span>
                <button
                  onClick={e => { e.stopPropagation(); navigate(banner.id === 3 ? 'loyalty' : 'shop') }}
                  style={{ padding: '6px 14px', borderRadius: 20, background: 'rgba(255,255,255,0.2)', color: '#fff', fontSize: 11, fontWeight: 600, border: '1px solid rgba(255,255,255,0.35)', backdropFilter: 'blur(8px)', cursor: 'pointer' }}
                >
                  {banner.cta}
                </button>
              </div>
            </div>
          </div>
        ))}
        {/* Dots */}
        <div style={{ position: 'absolute', bottom: 10, right: 16, display: 'flex', gap: 4 }}>
          {BANNERS.map((_, i) => (
            <button key={i} onClick={() => setActiveBanner(i)}
              style={{ width: activeBanner === i ? 16 : 5, height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.8)', transition: 'width 0.3s', border: 'none' }}
            />
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div style={{ padding: '0 20px 20px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {QUICK_ACTIONS.map(a => (
            <button key={a.label}
              onClick={() => navigate(a.target)}
              style={{ borderRadius: 14, padding: '12px 8px', background: cardBg, border: `1px solid ${border}`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer', transition: 'transform 0.15s' }}
              className="product-card"
            >
              <span style={{ fontSize: 22 }}>{a.icon}</span>
              <span style={{ fontSize: 10.5, fontWeight: 500, color: muted, textAlign: 'center' }}>{a.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div style={{ padding: '0 0 20px' }}>
        <SectionHeader title="Shop by Category" action="See all" onAction={() => navigate('shop')} isDark={isDark} />
        <div className="scroll-row" style={{ paddingLeft: 20, paddingRight: 20 }}>
          {CATEGORIES.slice(0, 8).map(cat => (
            <button key={cat.id}
              onClick={() => navigate('shop')}
              style={{ flex: '0 0 auto', borderRadius: 14, padding: '12px 14px', background: cat.color, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, minWidth: 76 }}
              className="product-card"
            >
              <span style={{ fontSize: 26 }}>{cat.icon}</span>
              <span style={{ fontSize: 10, fontWeight: 600, color: cat.accent, textAlign: 'center', whiteSpace: 'nowrap' }}>{cat.name}</span>
              <span style={{ fontSize: 9, color: cat.accent, opacity: 0.7 }}>{cat.count}+</span>
            </button>
          ))}
        </div>
      </div>

      {/* Flash Sale Section */}
      <div style={{ padding: '0 0 20px', margin: '0 20px 20px', borderRadius: 18, background: isDark ? '#1a1214' : '#fff5f5', overflow: 'hidden' }}>
        <div style={{ padding: '14px 16px 4px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 18 }}>⚡</span>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: '#dc2626' }}>Flash Sale</span>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            {[{ v: flashTime.h, l: 'h' }, { v: flashTime.m, l: 'm' }, { v: flashTime.s, l: 's' }].map(({ v, l }) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <span style={{ minWidth: 28, padding: '3px 6px', borderRadius: 6, background: '#dc2626', color: '#fff', fontSize: 12, fontFamily: 'var(--font-mono)', fontWeight: 500, textAlign: 'center' }}>{pad(v)}</span>
                <span style={{ fontSize: 11, color: '#dc2626', fontWeight: 700 }}>{l}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="scroll-row" style={{ paddingLeft: 16, paddingRight: 16 }}>
          {FLASH_SALES.map(p => (
            <FlashCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} isDark={isDark} />
          ))}
        </div>
      </div>

      {/* Fresh Today */}
      <div style={{ padding: '0 0 20px' }}>
        <SectionHeader title="Fresh Today" action="See all" onAction={() => navigate('shop')} isDark={isDark} sub="Arrived this morning" />
        <div className="scroll-row" style={{ paddingLeft: 20, paddingRight: 20 }}>
          {FRESH_TODAY.map(p => (
            <ProductCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} wishlisted={wishlist.includes(p.id)} onWishlist={toggleWishlist} isDark={isDark} />
          ))}
        </div>
      </div>

      {/* Trending */}
      <div style={{ padding: '0 0 20px' }}>
        <SectionHeader title="Trending Now 🔥" action="View all" onAction={() => navigate('shop')} isDark={isDark} />
        <div className="scroll-row" style={{ paddingLeft: 20, paddingRight: 20 }}>
          {TRENDING.map(p => (
            <ProductCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} wishlisted={wishlist.includes(p.id)} onWishlist={toggleWishlist} isDark={isDark} />
          ))}
        </div>
      </div>

      {/* Meal Planner Promo */}
      <div onClick={() => navigate('shop')} style={{ margin: '0 20px 20px', borderRadius: 18, overflow: 'hidden', position: 'relative', height: 110, cursor: 'pointer' }}>
        <Img src="https://images.unsplash.com/photo-1466637574441-749b8f19452f?w=600&h=200&fit=crop&auto=format" alt="Meal planning" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(10,79,46,0.9) 0%, rgba(10,79,46,0.4) 100%)' }} />
        <div style={{ position: 'absolute', inset: 0, padding: '16px 20px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', marginBottom: 4 }}>AI Feature</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700, color: '#fff', marginBottom: 4 }}>Smart Meal Planner</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.8)' }}>Get a 7-day plan with auto-filled cart</div>
        </div>
        <button onClick={e => { e.stopPropagation(); navigate('shop') }} style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', padding: '8px 16px', borderRadius: 20, background: '#fff', color: '#0a4f2e', fontSize: 11, fontWeight: 700, border: 'none', cursor: 'pointer' }}>
          Try Now
        </button>
      </div>

      {/* All Products */}
      <div style={{ padding: '0 0 20px' }}>
        <SectionHeader title="All Products" action="See more" onAction={() => navigate('shop')} isDark={isDark} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: '0 20px' }}>
          {PRODUCTS.slice(0, 6).map(p => (
            <GridCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} wishlisted={wishlist.includes(p.id)} onWishlist={toggleWishlist} isDark={isDark} />
          ))}
        </div>
      </div>

      <div style={{ height: 16 }} />
    </div>
  )
}

function SectionHeader({ title, action, onAction, isDark, sub }: { title: string; action?: string; onAction?: () => void; isDark: boolean; sub?: string }) {
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  return (
    <div style={{ padding: '0 20px 12px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700, color: text }}>{title}</div>
        {sub && <div style={{ fontSize: 11, color: muted, marginTop: 1 }}>{sub}</div>}
      </div>
      {action && (
        <button onClick={onAction} style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 600, paddingTop: 2 }}>{action}</button>
      )}
    </div>
  )
}

function FlashCard({ product, onOpen, onAdd, added, isDark }: { product: Product; onOpen: (p: Product) => void; onAdd: (p: Product) => void; added: boolean; isDark: boolean }) {
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const disc = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0

  return (
    <div className="product-card" style={{ flex: '0 0 130px', borderRadius: 14, background: cardBg, overflow: 'hidden', cursor: 'pointer' }} onClick={() => onOpen(product)}>
      <div style={{ height: 100, overflow: 'hidden', position: 'relative' }}>
        <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <span style={{ position: 'absolute', top: 8, left: 8, background: '#dc2626', color: '#fff', fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 6 }}>
          -{disc}%
        </span>
      </div>
      <div style={{ padding: '8px 10px' }}>
        <div style={{ fontSize: 11, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{product.name}</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 6 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#dc2626' }}>₹{product.price}</span>
          <span style={{ fontSize: 10, color: muted, textDecoration: 'line-through' }}>₹{product.originalPrice}</span>
        </div>
        <button
          onClick={e => { e.stopPropagation(); onAdd(product) }}
          style={{ width: '100%', padding: '5px 0', borderRadius: 8, background: added ? '#e8f5ee' : '#0a4f2e', color: added ? '#0a4f2e' : '#fff', fontSize: 11, fontWeight: 600, transition: 'all 0.2s', border: 'none', cursor: 'pointer' }}
        >
          {added ? '✓ Added' : 'Add'}
        </button>
      </div>
    </div>
  )
}

function ProductCard({ product, onOpen, onAdd, added, wishlisted, onWishlist, isDark }: {
  product: Product; onOpen: (p: Product) => void; onAdd: (p: Product) => void; added: boolean; wishlisted: boolean; onWishlist: (id: number) => void; isDark: boolean
}) {
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'

  return (
    <div className="product-card" style={{ flex: '0 0 150px', borderRadius: 16, background: cardBg, overflow: 'hidden', cursor: 'pointer', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }} onClick={() => onOpen(product)}>
      <div style={{ height: 120, overflow: 'hidden', position: 'relative' }}>
        <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        {product.badge && (
          <span style={{ position: 'absolute', top: 8, left: 8, background: product.badgeColor || '#0a4f2e', color: '#fff', fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 6 }}>
            {product.badge}
          </span>
        )}
        <button
          onClick={e => { e.stopPropagation(); onWishlist(product.id) }}
          style={{ position: 'absolute', top: 6, right: 6, width: 26, height: 26, borderRadius: 8, background: 'rgba(255,255,255,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer' }}
        >
          <span style={{ fontSize: 13 }}>{wishlisted ? '❤️' : '🤍'}</span>
        </button>
      </div>
      <div style={{ padding: '8px 10px 10px' }}>
        <div style={{ fontSize: 10, color: muted, marginBottom: 2 }}>{product.brand}</div>
        <div style={{ fontSize: 12, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{product.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginBottom: 6 }}>
          <span style={{ fontSize: 10, color: '#f59e0b' }}>★</span>
          <span style={{ fontSize: 10, color: muted }}>{product.rating}</span>
          <span style={{ fontSize: 10, color: muted }}>({product.reviewCount})</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#0a4f2e' }}>₹{product.price}</span>
            <span style={{ fontSize: 10, color: muted, display: 'block' }}>{product.unit}</span>
          </div>
          <button
            onClick={e => { e.stopPropagation(); onAdd(product) }}
            style={{ width: 28, height: 28, borderRadius: 8, background: added ? '#e8f5ee' : '#0a4f2e', color: added ? '#0a4f2e' : '#fff', fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer', transition: 'all 0.2s' }}
          >
            {added ? '✓' : '+'}
          </button>
        </div>
      </div>
    </div>
  )
}

function GridCard({ product, onOpen, onAdd, added, wishlisted, onWishlist, isDark }: {
  product: Product; onOpen: (p: Product) => void; onAdd: (p: Product) => void; added: boolean; wishlisted: boolean; onWishlist: (id: number) => void; isDark: boolean
}) {
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'

  return (
    <div className="product-card" style={{ borderRadius: 16, background: cardBg, overflow: 'hidden', cursor: 'pointer', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }} onClick={() => onOpen(product)}>
      <div style={{ height: 140, overflow: 'hidden', position: 'relative' }}>
        <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        {product.badge && (
          <span style={{ position: 'absolute', top: 8, left: 8, background: product.badgeColor || '#0a4f2e', color: '#fff', fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 6 }}>
            {product.badge}
          </span>
        )}
        <button
          onClick={e => { e.stopPropagation(); onWishlist(product.id) }}
          style={{ position: 'absolute', top: 6, right: 6, width: 26, height: 26, borderRadius: 8, background: 'rgba(255,255,255,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer' }}
        >
          <span style={{ fontSize: 13 }}>{wishlisted ? '❤️' : '🤍'}</span>
        </button>
      </div>
      <div style={{ padding: '10px 12px 12px' }}>
        <div style={{ fontSize: 10, color: muted, marginBottom: 2 }}>{product.brand}</div>
        <div style={{ fontSize: 12, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 4 }}>{product.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <span style={{ fontSize: 15, fontWeight: 700, color: '#0a4f2e' }}>₹{product.price}</span>
            {product.originalPrice && <span style={{ fontSize: 10, color: muted, textDecoration: 'line-through', marginLeft: 4 }}>₹{product.originalPrice}</span>}
            <span style={{ fontSize: 10, color: muted, display: 'block' }}>{product.unit}</span>
          </div>
          <button
            onClick={e => { e.stopPropagation(); onAdd(product) }}
            style={{ width: 30, height: 30, borderRadius: 9, background: added ? '#e8f5ee' : '#0a4f2e', color: added ? '#0a4f2e' : '#fff', fontSize: 18, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer', transition: 'all 0.2s' }}
          >
            {added ? '✓' : '+'}
          </button>
        </div>
      </div>
    </div>
  )
}
