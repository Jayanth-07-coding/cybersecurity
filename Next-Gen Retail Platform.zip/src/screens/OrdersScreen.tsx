import { useState } from 'react'
import Img from '../components/Img'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
}

const ORDERS = [
  {
    id: 'FM-2024-8471',
    date: 'Today, Jul 24',
    status: 'out_for_delivery' as const,
    eta: 'Arriving by 5:30 PM',
    items: [
      { name: 'Organic Alphonso Mangoes', qty: 2, price: 299, image: 'https://images.unsplash.com/photo-1605027990121-cbae9e0642df?w=100&h=100&fit=crop&auto=format' },
      { name: 'Greek Yogurt Natural', qty: 1, price: 85, image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=100&h=100&fit=crop&auto=format' },
      { name: 'Cold Press Orange Juice', qty: 3, price: 149, image: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=100&h=100&fit=crop&auto=format' },
    ],
    total: 1030,
    address: '42, 7th Cross, HSR Layout',
    partner: { name: 'Ravi Kumar', rating: 4.9, vehicle: 'Scooter — KA 04 HX 7821', phone: '+91 94823 12345' },
  },
  {
    id: 'FM-2024-8310',
    date: 'Jul 20, 2024',
    status: 'delivered' as const,
    eta: 'Delivered at 6:15 PM',
    items: [
      { name: 'Amul Gold Full Cream Milk', qty: 4, price: 31, image: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=100&h=100&fit=crop&auto=format' },
      { name: 'Free Range Brown Eggs', qty: 2, price: 109, image: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?w=100&h=100&fit=crop&auto=format' },
    ],
    total: 342,
    address: '42, 7th Cross, HSR Layout',
    partner: null,
  },
  {
    id: 'FM-2024-8189',
    date: 'Jul 15, 2024',
    status: 'delivered' as const,
    eta: 'Delivered at 11:45 AM',
    items: [
      { name: 'Artisan Sourdough Bread', qty: 1, price: 199, image: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=100&h=100&fit=crop&auto=format' },
      { name: 'Norwegian Salmon Fillet', qty: 1, price: 899, image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=100&h=100&fit=crop&auto=format' },
      { name: 'Premium Matcha Powder', qty: 1, price: 549, image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=100&h=100&fit=crop&auto=format' },
    ],
    total: 1647,
    address: '42, 7th Cross, HSR Layout',
    partner: null,
  },
]

const STATUS_CONFIG = {
  out_for_delivery: { label: 'Out for Delivery', color: '#f59e0b', bg: '#fef3c7', icon: '🚚' },
  delivered: { label: 'Delivered', color: '#0a4f2e', bg: '#e8f5ee', icon: '✅' },
  processing: { label: 'Processing', color: '#3b82f6', bg: '#eff6ff', icon: '⚙️' },
  cancelled: { label: 'Cancelled', color: '#dc2626', bg: '#fee2e2', icon: '❌' },
}

const TRACK_STEPS = [
  { label: 'Order Placed', time: '2:30 PM', done: true },
  { label: 'Confirmed', time: '2:32 PM', done: true },
  { label: 'Packed', time: '3:15 PM', done: true },
  { label: 'Out for Delivery', time: '4:45 PM', done: true },
  { label: 'Delivered', time: 'Est. 5:30 PM', done: false },
]

export default function OrdersScreen({ navigate }: Props) {
  const [selectedOrder, setSelectedOrder] = useState<string | null>(ORDERS[0].id)
  const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'delivered'>('all')

  const filtered = ORDERS.filter(o => {
    if (activeFilter === 'active') return o.status === 'out_for_delivery' || o.status === 'processing'
    if (activeFilter === 'delivered') return o.status === 'delivered'
    return true
  })

  const order = selectedOrder ? ORDERS.find(o => o.id === selectedOrder) : null

  return (
    <div style={{ background: '#f7f6f2', minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => navigate('account')} style={{ width: 36, height: 36, borderRadius: 12, background: '#fff', border: '1.5px solid #e4e0d8', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M19 12H5M12 5l-7 7 7 7" stroke="#14110e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: '#14110e' }}>My Orders</div>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, padding: '0 20px 16px' }}>
        {(['all', 'active', 'delivered'] as const).map(f => (
          <button key={f}
            onClick={() => setActiveFilter(f)}
            style={{ padding: '7px 16px', borderRadius: 20, background: activeFilter === f ? '#0a4f2e' : '#fff', color: activeFilter === f ? '#fff' : '#6b6455', fontSize: 12, fontWeight: 500, border: `1.5px solid ${activeFilter === f ? '#0a4f2e' : '#e4e0d8'}`, cursor: 'pointer', textTransform: 'capitalize', transition: 'all 0.15s' }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Active order tracking (hero) */}
      {order && order.status === 'out_for_delivery' && (
        <div style={{ margin: '0 20px 16px', borderRadius: 20, background: '#0a4f2e', overflow: 'hidden' }}>
          <div style={{ padding: '16px 16px 0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)', marginBottom: 2 }}>Order {order.id}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: '#fff' }}>{order.eta}</div>
              </div>
              <div style={{ fontSize: 32 }}>🚚</div>
            </div>

            {/* Track steps */}
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
              {TRACK_STEPS.map((step, i) => (
                <div key={step.label} style={{ display: 'flex', alignItems: 'center', flex: i < TRACK_STEPS.length - 1 ? 1 : 0 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
                    <div style={{ width: 22, height: 22, borderRadius: '50%', background: step.done ? '#fff' : 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10 }}>
                      {step.done ? <span style={{ color: '#0a4f2e', fontWeight: 700 }}>✓</span> : <span style={{ color: 'rgba(255,255,255,0.4)' }}>○</span>}
                    </div>
                  </div>
                  {i < TRACK_STEPS.length - 1 && (
                    <div style={{ flex: 1, height: 2, background: step.done ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.15)', margin: '0 2px' }} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Delivery partner */}
          {order.partner && (
            <div style={{ background: 'rgba(0,0,0,0.2)', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 12, background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>👤</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>{order.partner.name}</div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.65)' }}>{order.partner.vehicle}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => window.open(`tel:${order.partner?.phone}`)} style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: 'none' }}>
                  <span style={{ fontSize: 16 }}>📞</span>
                </button>
                <button onClick={() => window.open(`https://wa.me/${order.partner?.phone?.replace(/\D/g, '')}`)} style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: 'none' }}>
                  <span style={{ fontSize: 16 }}>💬</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Orders list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '0 20px 20px' }}>
        {filtered.map(o => {
          const cfg = STATUS_CONFIG[o.status]
          return (
            <div key={o.id} onClick={() => setSelectedOrder(o.id === selectedOrder ? null : o.id)}
              style={{ borderRadius: 16, background: '#fff', overflow: 'hidden', cursor: 'pointer', border: `1.5px solid ${selectedOrder === o.id ? '#0a4f2e' : '#e4e0d8'}` }}
            >
              {/* Order header */}
              <div style={{ padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 11, color: '#6b6455', marginBottom: 2 }}>{o.date}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#14110e', fontFamily: 'var(--font-mono)' }}>{o.id}</div>
                </div>
                <span style={{ fontSize: 10, fontWeight: 700, padding: '4px 9px', borderRadius: 8, background: cfg.bg, color: cfg.color, display: 'flex', alignItems: 'center', gap: 4 }}>
                  {cfg.icon} {cfg.label}
                </span>
              </div>

              {/* Items preview */}
              <div style={{ padding: '0 14px 12px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <div style={{ display: 'flex', gap: -8 }}>
                  {o.items.slice(0, 3).map((item, i) => (
                    <div key={i} style={{ width: 36, height: 36, borderRadius: 10, overflow: 'hidden', border: '2px solid #fff', marginLeft: i > 0 ? -10 : 0 }}>
                      <Img src={item.image} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  ))}
                  {o.items.length > 3 && (
                    <div style={{ width: 36, height: 36, borderRadius: 10, background: '#f7f6f2', border: '2px solid #fff', marginLeft: -10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#6b6455' }}>
                      +{o.items.length - 3}
                    </div>
                  )}
                </div>
                <div style={{ flex: 1, fontSize: 12, color: '#6b6455', display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {o.items.map(i => i.name).join(', ')}
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, color: '#0a4f2e', flexShrink: 0 }}>₹{o.total.toLocaleString()}</div>
              </div>

              {/* Actions */}
              <div onClick={e => e.stopPropagation()} style={{ padding: '10px 14px', background: '#f7f6f2', display: 'flex', gap: 10 }}>
                {o.status === 'delivered' ? (
                  <>
                    <button onClick={() => navigate('shop')} style={{ flex: 1, padding: '8px 0', borderRadius: 10, background: '#0a4f2e', color: '#fff', fontSize: 11, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Reorder</button>
                    <button onClick={() => alert(`Invoice for ${o.id} downloaded`)} style={{ flex: 1, padding: '8px 0', borderRadius: 10, background: 'transparent', color: '#0a4f2e', fontSize: 11, fontWeight: 600, border: '1.5px solid #0a4f2e', cursor: 'pointer' }}>Invoice</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => setSelectedOrder(o.id)} style={{ flex: 1, padding: '8px 0', borderRadius: 10, background: '#0a4f2e', color: '#fff', fontSize: 11, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Track Live</button>
                    <button onClick={() => alert(`Order ${o.id} cancellation requested`)} style={{ flex: 1, padding: '8px 0', borderRadius: 10, background: 'transparent', color: '#dc2626', fontSize: 11, fontWeight: 600, border: '1.5px solid #fecaca', cursor: 'pointer' }}>Cancel</button>
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
