import { FreshMartIcon, FreshMartLogo, FreshMartMark } from '../components/FreshMartMark'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
}

export default function BrandScreen({ navigate }: Props) {
  return (
    <div style={{ background: '#f7f6f2', minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 24px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button
          onClick={() => navigate('home')}
          style={{ width: 36, height: 36, borderRadius: 12, background: '#fff', border: '1.5px solid #e4e0d8', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M19 12H5M12 5l-7 7 7 7" stroke="#14110e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: '#14110e' }}>Brand Assets</div>
          <div style={{ fontSize: 11, color: '#6b6455' }}>Logo · App Icon · Mark</div>
        </div>
      </div>

      {/* ── App Icon ─────────────────────────────────── */}
      <Section label="App Icon">
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 24, padding: '24px 0 8px' }}>
          {/* iOS homescreen */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <FreshMartIcon size={120} radiusRatio={0.225} />
            <Chip>120 × 120</Chip>
            <Chip muted>iOS Home</Chip>
          </div>
          {/* Notification / smaller */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <FreshMartIcon size={76} radiusRatio={0.225} />
            <Chip>76 × 76</Chip>
            <Chip muted>Spotlight</Chip>
          </div>
          {/* Favicon */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <FreshMartIcon size={44} radiusRatio={0.225} />
            <Chip>44 × 44</Chip>
            <Chip muted>Tab / Favicon</Chip>
          </div>
        </div>

        {/* Scale floor test */}
        <div style={{ marginTop: 16, padding: '12px 16px', borderRadius: 12, background: '#fff', border: '1px solid #e4e0d8', display: 'flex', alignItems: 'center', gap: 12 }}>
          <FreshMartIcon size={28} radiusRatio={0.225} />
          <FreshMartIcon size={20} radiusRatio={0.225} />
          <FreshMartIcon size={16} radiusRatio={0.225} />
          <div style={{ marginLeft: 4 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#14110e' }}>Scale floor test — 28 / 20 / 16 px</div>
            <div style={{ fontSize: 10, color: '#6b6455' }}>Silhouette readable, sprout form legible at 28 px+</div>
          </div>
        </div>
      </Section>

      {/* ── Horizontal Logo ───────────────────────────── */}
      <Section label="Horizontal Logo">
        {/* On white */}
        <div style={{ borderRadius: 16, background: '#ffffff', border: '1px solid #e4e0d8', padding: '28px 24px', display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
          <FreshMartLogo variant="light" height={44} />
        </div>
        <Chip muted center>On white — primary usage</Chip>

        {/* On green */}
        <div style={{ borderRadius: 16, background: '#0a4f2e', padding: '28px 24px', display: 'flex', justifyContent: 'center', marginBottom: 10, marginTop: 12 }}>
          <FreshMartLogo variant="green" height={44} />
        </div>
        <Chip muted center>On brand green</Chip>

        {/* On dark */}
        <div style={{ borderRadius: 16, background: '#0f1a13', padding: '28px 24px', display: 'flex', justifyContent: 'center', marginBottom: 10, marginTop: 12 }}>
          <FreshMartLogo variant="dark" height={44} />
        </div>
        <Chip muted center>Dark mode</Chip>

        {/* Compact / small */}
        <div style={{ borderRadius: 16, background: '#ffffff', border: '1px solid #e4e0d8', padding: '18px 24px', display: 'flex', alignItems: 'center', gap: 24, marginTop: 12 }}>
          <FreshMartLogo variant="light" height={28} />
          <FreshMartLogo variant="light" height={20} />
          <FreshMartLogo variant="light" height={16} />
        </div>
        <Chip muted center>28 / 20 / 16 px — scale test</Chip>
      </Section>

      {/* ── Isolated Mark ────────────────────────────── */}
      <Section label="Isolated Mark — F-Sprout">
        <div style={{ borderRadius: 16, background: '#ffffff', border: '1px solid #e4e0d8', padding: '28px 24px' }}>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-end', gap: 32, marginBottom: 20 }}>
            {/* On green tile */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 80, height: 80, borderRadius: 20, background: '#0a4f2e', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FreshMartMark color="#ffffff" size={52} />
              </div>
              <Chip>On green</Chip>
            </div>
            {/* On white */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 80, height: 80, borderRadius: 20, background: '#f7f6f2', border: '1.5px solid #e4e0d8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FreshMartMark color="#0a4f2e" size={52} />
              </div>
              <Chip>On light</Chip>
            </div>
            {/* Gold accent */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 80, height: 80, borderRadius: 20, background: '#c9991a', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FreshMartMark color="#ffffff" size={52} />
              </div>
              <Chip>Gold accent</Chip>
            </div>
          </div>

          {/* Anatomy callout */}
          <div style={{ borderRadius: 12, background: '#f7f6f2', padding: '14px 16px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#14110e', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.8 }}>Mark Anatomy</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { dot: '#0a4f2e', label: 'Stem', desc: 'Calligraphic vertical — reads as the F stroke and the plant stem' },
                { dot: '#1a7a50', label: 'Top leaf', desc: 'Geometric leaf = F upper bar. Points right + slightly upward' },
                { dot: '#22c55e', label: 'Middle leaf', desc: 'F lower bar — shorter (⅔ width) for correct F proportion' },
                { dot: '#c9991a', label: 'Bud', desc: 'Rounded terminus at top — signals growth, finishes the stem' },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: row.dot, marginTop: 3, flexShrink: 0 }} />
                  <div>
                    <span style={{ fontSize: 11, fontWeight: 600, color: '#14110e' }}>{row.label} — </span>
                    <span style={{ fontSize: 11, color: '#6b6455' }}>{row.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* ── Colour Palette ────────────────────────────── */}
      <Section label="Brand Palette">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { name: 'Forest Green', hex: '#0a4f2e', role: 'Primary · interactive · brand' },
            { name: 'Warm Gold', hex: '#c9991a', role: 'Loyalty · premium · accent' },
            { name: 'Deep Green', hex: '#073d25', role: 'Dark surfaces · shadows' },
            { name: 'Off-White', hex: '#f7f6f2', role: 'Page background · breathing room' },
            { name: 'Warm Muted', hex: '#6b6455', role: 'Body text · captions' },
          ].map(c => (
            <div key={c.hex} style={{ display: 'flex', alignItems: 'center', gap: 12, borderRadius: 12, background: '#fff', border: '1px solid #e4e0d8', padding: '10px 14px' }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: c.hex, flexShrink: 0, border: c.hex === '#f7f6f2' ? '1px solid #e4e0d8' : 'none' }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#14110e' }}>{c.name}</div>
                <div style={{ fontSize: 11, color: '#6b6455' }}>{c.role}</div>
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#6b6455' }}>{c.hex}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* ── Typography ────────────────────────────────── */}
      <Section label="Brand Typography">
        <div style={{ borderRadius: 16, background: '#fff', border: '1px solid #e4e0d8', padding: '20px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, color: '#6b6455', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>Display — Fraunces</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: '#0a4f2e', lineHeight: 1.1 }}>Fresh from the farm,<br /><em style={{ fontWeight: 300 }}>delivered to your door.</em></div>
          </div>
          <div style={{ height: 1, background: '#e4e0d8' }} />
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, color: '#6b6455', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>Body — Inter</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: '#14110e', lineHeight: 1.65 }}>Premium groceries, seasonal produce, and everyday essentials — curated with care and delivered in 90 minutes.</div>
          </div>
          <div style={{ height: 1, background: '#e4e0d8' }} />
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, color: '#6b6455', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>Mono — DM Mono</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#0a4f2e', letterSpacing: 0.5 }}>FM-2024-8471 · +2,840 pts · ₹1,247.00</div>
          </div>
        </div>
      </Section>

      <div style={{ height: 24 }} />
    </div>
  )
}

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ padding: '0 20px 20px' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#6b6455', textTransform: 'uppercase', letterSpacing: 0.9, marginBottom: 10 }}>{label}</div>
      {children}
    </div>
  )
}

function Chip({ children, muted, center }: { children: React.ReactNode; muted?: boolean; center?: boolean }) {
  return (
    <div style={{ fontSize: 10, color: muted ? '#9a9480' : '#0a4f2e', fontWeight: muted ? 400 : 600, textAlign: center ? 'center' : undefined, marginTop: center ? 6 : 0 }}>
      {children}
    </div>
  )
}
