import { useState } from 'react'
import Img from '../components/Img'
import type { Product } from '../data/types'
import { PRODUCTS, CATEGORIES } from '../data/products'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  openProduct: (p: Product) => void
  addToCart: (p: Product) => void
  toggleWishlist: (id: number) => void
  wishlist: number[]
  isDark: boolean
  searchQuery: string
  setSearchQuery: (q: string) => void
}

const FILTERS = ['All', 'Organic', 'Fresh Today', 'On Sale', 'In Stock', 'Premium']
const SORT_OPTIONS = ['Relevance', 'Price: Low', 'Price: High', 'Rating', 'New']

export default function ShopScreen({ navigate, openProduct, addToCart, toggleWishlist, wishlist, isDark, searchQuery, setSearchQuery }: Props) {
  const [activeFilter, setActiveFilter] = useState('All')
  const [activeCategory, setActiveCategory] = useState('all')
  const [sortBy, setSortBy] = useState('Relevance')
  const [showSort, setShowSort] = useState(false)
  const [addedId, setAddedId] = useState<number | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  const handleAdd = (p: Product) => {
    addToCart(p)
    setAddedId(p.id)
    setTimeout(() => setAddedId(null), 1500)
  }

  const filtered = PRODUCTS.filter(p => {
    const q = searchQuery.toLowerCase()
    const matchesSearch = !q || p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
    const matchesCat = activeCategory === 'all' || p.category.toLowerCase().includes(activeCategory)
    const matchesFilter = activeFilter === 'All'
      || (activeFilter === 'Organic' && p.isOrganic)
      || (activeFilter === 'Fresh Today' && p.isNew)
      || (activeFilter === 'On Sale' && p.originalPrice)
      || (activeFilter === 'In Stock' && p.inStock)
      || (activeFilter === 'Premium' && (p.price > 200))
    return matchesSearch && matchesCat && matchesFilter
  }).sort((a, b) => {
    if (sortBy === 'Price: Low') return a.price - b.price
    if (sortBy === 'Price: High') return b.price - a.price
    if (sortBy === 'Rating') return b.rating - a.rating
    return 0
  })

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 12px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <svg style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} width="15" height="15" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="8" stroke={muted} strokeWidth="2"/>
            <path d="M21 21l-4.35-4.35" stroke={muted} strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search products..."
            style={{ width: '100%', padding: '10px 12px 10px 36px', borderRadius: 12, border: `1.5px solid ${border}`, background: cardBg, fontFamily: 'var(--font-body)', fontSize: 13, color: text, outline: 'none' }}
          />
        </div>
        <button onClick={() => setShowSort(!showSort)} style={{ width: 40, height: 40, borderRadius: 12, background: cardBg, border: `1.5px solid ${border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M7 12h10M10 18h4" stroke={text} strokeWidth="2" strokeLinecap="round"/></svg>
        </button>
        <button
          onClick={() => setViewMode(v => v === 'grid' ? 'list' : 'grid')}
          style={{ width: 40, height: 40, borderRadius: 12, background: cardBg, border: `1.5px solid ${border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
        >
          {viewMode === 'grid'
            ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="7" height="7" rx="2" stroke={text} strokeWidth="2"/><rect x="14" y="3" width="7" height="7" rx="2" stroke={text} strokeWidth="2"/><rect x="3" y="14" width="7" height="7" rx="2" stroke={text} strokeWidth="2"/><rect x="14" y="14" width="7" height="7" rx="2" stroke={text} strokeWidth="2"/></svg>
            : <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" stroke={text} strokeWidth="2" strokeLinecap="round"/></svg>
          }
        </button>
      </div>

      {/* Sort dropdown */}
      {showSort && (
        <div style={{ margin: '0 20px 12px', borderRadius: 14, background: cardBg, border: `1px solid ${border}`, overflow: 'hidden' }}>
          {SORT_OPTIONS.map(opt => (
            <button key={opt}
              onClick={() => { setSortBy(opt); setShowSort(false) }}
              style={{ width: '100%', padding: '10px 16px', textAlign: 'left', fontSize: 13, color: sortBy === opt ? '#0a4f2e' : text, fontWeight: sortBy === opt ? 600 : 400, background: 'none', border: 'none', cursor: 'pointer', borderBottom: `1px solid ${border}` }}
            >
              {opt} {sortBy === opt && '✓'}
            </button>
          ))}
        </div>
      )}

      {/* Category pills */}
      <div className="scroll-row" style={{ padding: '0 20px 12px' }}>
        <button
          onClick={() => setActiveCategory('all')}
          style={{ flex: '0 0 auto', padding: '7px 16px', borderRadius: 20, background: activeCategory === 'all' ? '#0a4f2e' : cardBg, color: activeCategory === 'all' ? '#fff' : muted, fontSize: 12, fontWeight: 500, border: `1.5px solid ${activeCategory === 'all' ? '#0a4f2e' : border}`, cursor: 'pointer', transition: 'all 0.15s' }}
        >
          All
        </button>
        {CATEGORIES.map(cat => (
          <button key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            style={{ flex: '0 0 auto', padding: '7px 14px', borderRadius: 20, background: activeCategory === cat.id ? '#0a4f2e' : cardBg, color: activeCategory === cat.id ? '#fff' : muted, fontSize: 12, fontWeight: 500, border: `1.5px solid ${activeCategory === cat.id ? '#0a4f2e' : border}`, cursor: 'pointer', transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap' }}
          >
            <span>{cat.icon}</span>
            <span>{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Filter chips */}
      <div className="scroll-row" style={{ padding: '0 20px 16px' }}>
        {FILTERS.map(f => (
          <button key={f}
            onClick={() => setActiveFilter(f)}
            style={{ flex: '0 0 auto', padding: '5px 12px', borderRadius: 20, background: activeFilter === f ? '#e8f5ee' : 'transparent', color: activeFilter === f ? '#0a4f2e' : muted, fontSize: 11, fontWeight: activeFilter === f ? 600 : 400, border: `1.5px solid ${activeFilter === f ? '#0a4f2e' : border}`, cursor: 'pointer', transition: 'all 0.15s', whiteSpace: 'nowrap' }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Result count */}
      <div style={{ padding: '0 20px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, color: muted }}>{filtered.length} products</span>
        <span style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 500 }}>Sorted by: {sortBy}</span>
      </div>

      {/* Products */}
      {viewMode === 'grid' ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: '0 20px 20px' }}>
          {filtered.map(p => (
            <GridProductCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} wishlisted={wishlist.includes(p.id)} onWishlist={toggleWishlist} isDark={isDark} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '0 20px 20px' }}>
          {filtered.map(p => (
            <ListProductCard key={p.id} product={p} onOpen={openProduct} onAdd={handleAdd} added={addedId === p.id} wishlisted={wishlist.includes(p.id)} onWishlist={toggleWishlist} isDark={isDark} />
          ))}
        </div>
      )}

      {filtered.length === 0 && (
        <div style={{ padding: '60px 40px', textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: text, marginBottom: 8 }}>No products found</div>
          <div style={{ fontSize: 13, color: muted }}>Try adjusting your search or filters</div>
        </div>
      )}
    </div>
  )
}

function GridProductCard({ product, onOpen, onAdd, added, wishlisted, onWishlist, isDark }: {
  product: Product; onOpen: (p: Product) => void; onAdd: (p: Product) => void; added: boolean; wishlisted: boolean; onWishlist: (id: number) => void; isDark: boolean
}) {
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'

  return (
    <div className="product-card" style={{ borderRadius: 16, background: cardBg, overflow: 'hidden', cursor: 'pointer', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }} onClick={() => onOpen(product)}>
      <div style={{ height: 140, overflow: 'hidden', position: 'relative' }}>
        <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        {product.badge && (
          <span style={{ position: 'absolute', top: 8, left: 8, background: product.badgeColor || '#0a4f2e', color: '#fff', fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 6 }}>
            {product.badge}
          </span>
        )}
        {product.isOrganic && (
          <span style={{ position: 'absolute', bottom: 8, left: 8, background: '#0a4f2e', color: '#fff', fontSize: 8, fontWeight: 700, padding: '2px 6px', borderRadius: 6, display: 'flex', alignItems: 'center', gap: 3 }}>
            🌿 Organic
          </span>
        )}
        <button
          onClick={e => { e.stopPropagation(); onWishlist(product.id) }}
          style={{ position: 'absolute', top: 6, right: 6, width: 26, height: 26, borderRadius: 8, background: 'rgba(255,255,255,0.9)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer' }}
        >
          <span style={{ fontSize: 13 }}>{wishlisted ? '❤️' : '🤍'}</span>
        </button>
      </div>
      <div style={{ padding: '10px 12px 12px' }}>
        <div style={{ fontSize: 10, color: muted, marginBottom: 2 }}>{product.brand}</div>
        <div style={{ fontSize: 12, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 4, minHeight: 30 }}>{product.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginBottom: 6 }}>
          <span style={{ fontSize: 10, color: '#f59e0b' }}>★ {product.rating}</span>
          <span style={{ fontSize: 10, color: muted }}>({product.reviewCount})</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0a4f2e' }}>₹{product.price}</div>
            {product.originalPrice && <div style={{ fontSize: 10, color: muted, textDecoration: 'line-through' }}>₹{product.originalPrice}</div>}
            <div style={{ fontSize: 9.5, color: muted }}>{product.unit}</div>
          </div>
          <button
            onClick={e => { e.stopPropagation(); onAdd(product) }}
            style={{ width: 32, height: 32, borderRadius: 10, background: added ? '#e8f5ee' : '#0a4f2e', color: added ? '#0a4f2e' : '#fff', fontSize: 18, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer', transition: 'all 0.2s' }}
          >
            {added ? '✓' : '+'}
          </button>
        </div>
      </div>
    </div>
  )
}

function ListProductCard({ product, onOpen, onAdd, added, wishlisted, onWishlist, isDark }: {
  product: Product; onOpen: (p: Product) => void; onAdd: (p: Product) => void; added: boolean; wishlisted: boolean; onWishlist: (id: number) => void; isDark: boolean
}) {
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'

  return (
    <div className="product-card" style={{ borderRadius: 16, background: cardBg, overflow: 'hidden', cursor: 'pointer', display: 'flex', gap: 0, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }} onClick={() => onOpen(product)}>
      <div style={{ width: 100, minHeight: 100, flexShrink: 0, position: 'relative', overflow: 'hidden' }}>
        <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        {product.isOrganic && (
          <span style={{ position: 'absolute', top: 6, left: 6, background: '#0a4f2e', color: '#fff', fontSize: 8, fontWeight: 700, padding: '2px 5px', borderRadius: 4 }}>🌿</span>
        )}
      </div>
      <div style={{ flex: 1, padding: '12px 14px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 10, color: muted, marginBottom: 2 }}>{product.brand} · {product.unit}</div>
          <div style={{ fontSize: 13, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 4 }}>{product.name}</div>
          <div style={{ fontSize: 11, color: muted, marginBottom: 6, display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
            {product.description}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 11, color: '#f59e0b' }}>★ {product.rating}</span>
            <span style={{ fontSize: 11, color: muted }}>({product.reviewCount})</span>
            {product.badge && <span style={{ fontSize: 9, background: product.badgeColor || '#0a4f2e', color: '#fff', padding: '1px 5px', borderRadius: 4, fontWeight: 600 }}>{product.badge}</span>}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#0a4f2e' }}>₹{product.price}</span>
            {product.originalPrice && <span style={{ fontSize: 11, color: muted, textDecoration: 'line-through' }}>₹{product.originalPrice}</span>}
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <button onClick={e => { e.stopPropagation(); onWishlist(product.id) }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16 }}>
              {wishlisted ? '❤️' : '🤍'}
            </button>
            <button
              onClick={e => { e.stopPropagation(); onAdd(product) }}
              style={{ padding: '6px 14px', borderRadius: 10, background: added ? '#e8f5ee' : '#0a4f2e', color: added ? '#0a4f2e' : '#fff', fontSize: 11, fontWeight: 600, border: 'none', cursor: 'pointer', transition: 'all 0.2s' }}
            >
              {added ? '✓ Added' : '+ Add'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
