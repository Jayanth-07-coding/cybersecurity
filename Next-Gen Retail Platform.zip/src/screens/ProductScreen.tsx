import { useState } from 'react'
import Img from '../components/Img'
import type { Product } from '../data/types'
import { PRODUCTS } from '../data/products'

interface Props {
  product: Product
  inCart: number
  back: () => void
  addToCart: (p: Product, qty?: number) => void
  toggleWishlist: (id: number) => void
  wishlist: number[]
  isDark: boolean
  openProduct: (p: Product) => void
}

const REVIEWS = [
  { name: 'Ananya R.', rating: 5, date: '2 days ago', text: 'Exceptional quality! Freshest I\'ve had in a long time. Delivery was prompt and packaging perfect.', verified: true },
  { name: 'Rohan M.', rating: 4, date: '1 week ago', text: 'Great product, as described. Would have given 5 stars if it was slightly larger.', verified: true },
  { name: 'Meera K.', rating: 5, date: '2 weeks ago', text: 'This is my weekly staple now. Never going back to supermarket alternatives.', verified: false },
]

export default function ProductScreen({ product, inCart, back, addToCart, toggleWishlist, wishlist, isDark, openProduct }: Props) {
  const [qty, setQty] = useState(1)
  const [activeTab, setActiveTab] = useState<'details' | 'nutrition' | 'reviews'>('details')
  const [imgIdx, setImgIdx] = useState(0)
  const [added, setAdded] = useState(false)

  const isWishlisted = wishlist.includes(product.id)
  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  const disc = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0

  const similarProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4)

  const handleAddToCart = () => {
    addToCart(product, qty)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  // Mock images array (reuse main image with slight variation)
  const images = [product.image, product.image.replace('w=400', 'w=402'), product.image.replace('w=400', 'w=401')]

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      {/* Image area */}
      <div style={{ position: 'relative', height: 320, background: '#e8e3d9' }}>
        <Img src={images[imgIdx]} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />

        {/* Gradient overlay at top */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 80, background: 'linear-gradient(to bottom, rgba(0,0,0,0.35), transparent)' }} />

        {/* Back + actions */}
        <div style={{ position: 'absolute', top: 44, left: 0, right: 0, padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={back} style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M19 12H5M12 5l-7 7 7 7" stroke="#14110e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => toggleWishlist(product.id)} style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 17 }}>
              {isWishlisted ? '❤️' : '🤍'}
            </button>
            <button style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8M16 6l-4-4-4 4M12 2v13" stroke="#14110e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
        </div>

        {/* Badges on image */}
        {product.badge && (
          <div style={{ position: 'absolute', bottom: 16, left: 16 }}>
            <span style={{ background: product.badgeColor || '#0a4f2e', color: '#fff', fontSize: 11, fontWeight: 700, padding: '4px 10px', borderRadius: 8 }}>{product.badge}</span>
          </div>
        )}

        {/* Image dots */}
        <div style={{ position: 'absolute', bottom: 16, right: 16, display: 'flex', gap: 5 }}>
          {images.map((_, i) => (
            <button key={i} onClick={() => setImgIdx(i)}
              style={{ width: i === imgIdx ? 18 : 6, height: 6, borderRadius: 3, background: i === imgIdx ? '#fff' : 'rgba(255,255,255,0.5)', border: 'none', cursor: 'pointer', transition: 'width 0.2s' }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ background: cardBg, borderRadius: '20px 20px 0 0', marginTop: -20, padding: '20px 20px 0', position: 'relative', zIndex: 2 }}>
        {/* Brand + name */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: '#0a4f2e', fontWeight: 600, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{product.brand}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: text, lineHeight: 1.2 }}>{product.name}</div>
          </div>
        </div>

        {/* Rating */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <div style={{ display: 'flex', gap: 2 }}>
            {[1,2,3,4,5].map(s => (
              <span key={s} style={{ fontSize: 13, color: s <= Math.round(product.rating) ? '#f59e0b' : '#d1d5db' }}>★</span>
            ))}
          </div>
          <span style={{ fontSize: 12, fontWeight: 600, color: text }}>{product.rating}</span>
          <span style={{ fontSize: 12, color: muted }}>({product.reviewCount} reviews)</span>
          <span style={{ fontSize: 11, color: '#0a4f2e', fontWeight: 500 }}>• {product.inStock ? 'In Stock' : 'Out of Stock'}</span>
        </div>

        {/* Tags */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 16 }}>
          {product.tags.map(tag => (
            <span key={tag} style={{ padding: '3px 9px', borderRadius: 20, background: '#e8f5ee', color: '#0a4f2e', fontSize: 10, fontWeight: 500 }}>
              {tag}
            </span>
          ))}
          {product.isOrganic && (
            <span style={{ padding: '3px 9px', borderRadius: 20, background: '#e8f5ee', color: '#0a4f2e', fontSize: 10, fontWeight: 500 }}>🌿 Certified Organic</span>
          )}
        </div>

        {/* Price */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 8 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: '#0a4f2e' }}>₹{product.price}</span>
          {product.originalPrice && (
            <>
              <span style={{ fontSize: 16, color: muted, textDecoration: 'line-through' }}>₹{product.originalPrice}</span>
              <span style={{ fontSize: 12, color: '#dc2626', fontWeight: 700, background: '#fee2e2', padding: '2px 7px', borderRadius: 6 }}>{disc}% OFF</span>
            </>
          )}
        </div>
        <div style={{ fontSize: 12, color: muted, marginBottom: 20 }}>{product.unit} · Delivery in 90 min</div>

        {/* Qty + Add to Cart */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 0, borderRadius: 12, border: `1.5px solid ${border}`, overflow: 'hidden' }}>
            <button onClick={() => setQty(q => Math.max(1, q - 1))} style={{ width: 40, height: 46, background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: text }}>−</button>
            <span style={{ width: 36, textAlign: 'center', fontSize: 15, fontWeight: 600, color: text }}>{qty}</span>
            <button onClick={() => setQty(q => q + 1)} style={{ width: 40, height: 46, background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#0a4f2e' }}>+</button>
          </div>
          <button
            onClick={handleAddToCart}
            style={{ flex: 1, height: 46, borderRadius: 12, background: added ? '#1a7a50' : '#0a4f2e', color: '#fff', fontSize: 14, fontWeight: 700, border: 'none', cursor: 'pointer', transition: 'background 0.2s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
          >
            {added ? '✓ Added to Cart' : `Add to Cart · ₹${(product.price * qty).toLocaleString()}`}
          </button>
        </div>

        {/* Delivery info */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 20 }}>
          {[
            { icon: '🚚', label: 'Express', sub: '90 min delivery' },
            { icon: '↩️', label: 'Returns', sub: '7-day policy' },
            { icon: '🔒', label: 'Secure', sub: 'Safe payment' },
          ].map(item => (
            <div key={item.label} style={{ borderRadius: 12, background: isDark ? '#162318' : '#f7f6f2', padding: '10px 8px', textAlign: 'center' }}>
              <div style={{ fontSize: 18, marginBottom: 4 }}>{item.icon}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: text }}>{item.label}</div>
              <div style={{ fontSize: 9.5, color: muted }}>{item.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background: cardBg, marginTop: 8 }}>
        <div style={{ display: 'flex', borderBottom: `1px solid ${border}` }}>
          {(['details', 'nutrition', 'reviews'] as const).map(tab => (
            <button key={tab}
              onClick={() => setActiveTab(tab)}
              style={{ flex: 1, padding: '14px 0', fontSize: 12, fontWeight: activeTab === tab ? 700 : 500, color: activeTab === tab ? '#0a4f2e' : muted, borderBottom: activeTab === tab ? '2.5px solid #0a4f2e' : '2.5px solid transparent', background: 'none', border: 'none', cursor: 'pointer', textTransform: 'capitalize', transition: 'all 0.15s' }}
            >
              {tab}
            </button>
          ))}
        </div>

        <div style={{ padding: '16px 20px' }}>
          {activeTab === 'details' && (
            <div>
              <p style={{ fontSize: 13, color: text, lineHeight: 1.7, marginBottom: 16 }}>{product.description}</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { label: 'Category', value: product.category },
                  { label: 'Brand', value: product.brand },
                  { label: 'Unit', value: product.unit },
                  { label: 'Stock', value: product.inStock ? `${product.stockQty || 'Available'} units` : 'Out of stock' },
                  { label: 'Organic', value: product.isOrganic ? '✓ Certified' : 'No' },
                ].map(row => (
                  <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${border}` }}>
                    <span style={{ fontSize: 12, color: muted }}>{row.label}</span>
                    <span style={{ fontSize: 12, fontWeight: 500, color: text }}>{row.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'nutrition' && (
            <div>
              <div style={{ marginBottom: 12, fontSize: 12, color: muted }}>Per 100g serving</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  { name: 'Calories', value: '68 kcal', pct: 34 },
                  { name: 'Protein', value: '1.8g', pct: 22 },
                  { name: 'Carbohydrates', value: '14.2g', pct: 48 },
                  { name: 'Fat', value: '0.4g', pct: 8 },
                  { name: 'Fiber', value: '2.1g', pct: 42 },
                  { name: 'Vitamin C', value: '36mg', pct: 60 },
                ].map(item => (
                  <div key={item.name}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ fontSize: 12, color: text }}>{item.name}</span>
                      <span style={{ fontSize: 12, color: muted, fontFamily: 'var(--font-mono)' }}>{item.value}</span>
                    </div>
                    <div style={{ height: 4, borderRadius: 2, background: border, overflow: 'hidden' }}>
                      <div className="progress-fill" style={{ height: '100%', width: `${item.pct}%`, borderRadius: 2, background: '#0a4f2e' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div>
              <div style={{ display: 'flex', gap: 16, marginBottom: 16, padding: '12px', background: isDark ? '#162318' : '#f7f6f2', borderRadius: 12 }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, fontWeight: 700, color: '#0a4f2e' }}>{product.rating}</div>
                  <div style={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
                    {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize: 12, color: s <= Math.round(product.rating) ? '#f59e0b' : '#d1d5db' }}>★</span>)}
                  </div>
                  <div style={{ fontSize: 10, color: muted }}>{product.reviewCount} reviews</div>
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
                  {[5,4,3,2,1].map(star => (
                    <div key={star} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontSize: 10, color: muted, width: 6 }}>{star}</span>
                      <div style={{ flex: 1, height: 4, borderRadius: 2, background: border, overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${[72, 18, 6, 2, 2][5 - star]}%`, background: '#f59e0b', borderRadius: 2 }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {REVIEWS.map((r, i) => (
                <div key={i} style={{ padding: '12px 0', borderBottom: `1px solid ${border}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ width: 28, height: 28, borderRadius: 8, background: '#e8f5ee', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#0a4f2e' }}>
                        {r.name[0]}
                      </div>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: text }}>{r.name}</div>
                        {r.verified && <div style={{ fontSize: 9, color: '#0a4f2e', fontWeight: 500 }}>✓ Verified purchase</div>}
                      </div>
                    </div>
                    <span style={{ fontSize: 10, color: muted }}>{r.date}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 2, marginBottom: 6 }}>
                    {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize: 11, color: s <= r.rating ? '#f59e0b' : '#d1d5db' }}>★</span>)}
                  </div>
                  <p style={{ fontSize: 12, color: text, lineHeight: 1.6 }}>{r.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Similar products */}
      {similarProducts.length > 0 && (
        <div style={{ background: cardBg, marginTop: 8, padding: '16px 0 20px' }}>
          <div style={{ padding: '0 20px 12px', fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: text }}>You Might Also Like</div>
          <div className="scroll-row" style={{ paddingLeft: 20, paddingRight: 20 }}>
            {similarProducts.map(p => (
              <div key={p.id} className="product-card" onClick={() => openProduct(p)} style={{ flex: '0 0 130px', borderRadius: 14, background: isDark ? '#162318' : '#f7f6f2', overflow: 'hidden', cursor: 'pointer' }}>
                <div style={{ height: 90, overflow: 'hidden' }}>
                  <Img src={p.image} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div style={{ padding: '8px 10px' }}>
                  <div style={{ fontSize: 11, color: text, fontWeight: 500, lineHeight: 1.3, marginBottom: 3, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{p.name}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#0a4f2e' }}>₹{p.price}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ height: 24 }} />
    </div>
  )
}
