import { useState } from 'react'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  isDark: boolean
  cartTotal: number
}

const TIERS = [
  { name: 'Silver', min: 0, max: 999, color: 'loyalty-silver', icon: '🥈', perks: ['2% cashback', 'Birthday reward', 'Free delivery on ₹500+'] },
  { name: 'Gold', min: 1000, max: 4999, color: 'loyalty-gold', icon: '🥇', perks: ['4% cashback', '2× points weekends', 'Priority support', 'Exclusive flash sale access'] },
  { name: 'Platinum', min: 5000, max: 9999, color: 'loyalty-platinum', icon: '💎', perks: ['6% cashback', 'Free express delivery', 'Early access deals', 'Personal shopper'] },
  { name: 'Diamond', min: 10000, max: Infinity, color: 'loyalty-diamond', icon: '💠', perks: ['8% cashback', 'Concierge delivery', 'VIP member events', 'Surprise monthly boxes'] },
]

const HISTORY = [
  { date: 'Today', desc: 'Fresh produce order #8471', pts: +84, type: 'earn' },
  { date: 'Yesterday', desc: 'Redemption — discount on cart', pts: -200, type: 'redeem' },
  { date: 'Jul 20', desc: 'Weekend 2× bonus', pts: +156, type: 'bonus' },
  { date: 'Jul 18', desc: 'Referral reward — Kavya J.', pts: +500, type: 'bonus' },
  { date: 'Jul 15', desc: 'Dairy & eggs order #8310', pts: +31, type: 'earn' },
  { date: 'Jul 10', desc: 'Birthday cashback applied', pts: -150, type: 'redeem' },
]

const OFFERS = [
  { id: 1, title: '10% off Fresh Produce', sub: 'Valid today only', expiry: 'Today', code: 'FRESH10', color: '#e8f5ee', accent: '#0a4f2e' },
  { id: 2, title: 'Free Delivery', sub: 'Next 3 orders', expiry: 'Jul 31', code: 'FREESHIP', color: '#fef3e2', accent: '#c2691c' },
  { id: 3, title: '20% off Electronics', sub: 'Weekend special', expiry: 'Jul 28', code: 'ELEC20', color: '#f5f0ff', accent: '#7c3aed' },
]

const CHALLENGES = [
  { id: 1, title: 'Fresh Week', desc: 'Buy fresh produce 5 days in a row', progress: 3, total: 5, reward: '200 pts', icon: '🥬' },
  { id: 2, title: 'Healthy Shopper', desc: 'Spend ₹2000 on health products', progress: 1340, total: 2000, reward: '500 pts', icon: '💪' },
  { id: 3, title: 'Refer a Friend', desc: 'Invite 3 friends to FreshMart', progress: 1, total: 3, reward: '750 pts', icon: '👥' },
]

export default function LoyaltyScreen({ navigate, isDark }: Props) {
  const [activeTab, setActiveTab] = useState<'overview' | 'offers' | 'challenges' | 'history'>('overview')
  const [spinning, setSpinning] = useState(false)
  const [spinResult, setSpinResult] = useState<string | null>(null)
  const [spinAngle, setSpinAngle] = useState(0)

  const userPoints = 2840
  const currentTier = TIERS[1] // Gold
  const nextTier = TIERS[2]
  const progressToNext = (userPoints - currentTier.min) / (nextTier.min - currentTier.min)

  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  const handleSpin = () => {
    if (spinning) return
    setSpinning(true)
    setSpinResult(null)
    const prizes = ['50 pts', '100 pts', '10% OFF', '200 pts', 'Free Delivery', '25 pts']
    const prizeIdx = Math.floor(Math.random() * prizes.length)
    const targetAngle = spinAngle + 1440 + (prizeIdx * 60)
    setSpinAngle(targetAngle)
    setTimeout(() => {
      setSpinning(false)
      setSpinResult(prizes[prizeIdx])
    }, 3000)
  }

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: text }}>Rewards & Loyalty</div>
        <div style={{ fontSize: 12, color: muted, marginTop: 2 }}>Your membership benefits & offers</div>
      </div>

      {/* Gold Membership Card */}
      <div style={{ margin: '0 20px 20px', borderRadius: 20, overflow: 'hidden', position: 'relative' }}>
        <div className="loyalty-gold" style={{ padding: '20px 20px 16px' }}>
          {/* Decorative circles */}
          <div style={{ position: 'absolute', top: -30, right: -30, width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.1)' }} />
          <div style={{ position: 'absolute', bottom: -20, right: 40, width: 80, height: 80, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16, position: 'relative' }}>
            <div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 500, letterSpacing: 1, textTransform: 'uppercase' }}>FreshMart</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, color: '#fff', lineHeight: 1 }}>Gold Member</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 32 }}>🥇</div>
            </div>
          </div>

          <div style={{ marginBottom: 16, position: 'relative' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, fontWeight: 700, color: '#fff', letterSpacing: -1 }}>
              {userPoints.toLocaleString()}
            </div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>points available</div>
          </div>

          {/* Progress to Platinum */}
          <div style={{ position: 'relative' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)' }}>Progress to Platinum</span>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.9)', fontWeight: 600 }}>
                {(nextTier.min - userPoints).toLocaleString()} pts to go
              </span>
            </div>
            <div style={{ height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.25)', overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${Math.round(progressToNext * 100)}%`, borderRadius: 3, background: 'rgba(255,255,255,0.9)', transition: 'width 1.5s ease' }} />
            </div>
          </div>

          {/* Card number */}
          <div style={{ marginTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'rgba(255,255,255,0.8)', letterSpacing: 2 }}>
              FM •••• •••• 4821
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>Valid thru 12/25</div>
          </div>
        </div>

        {/* Quick stats below card */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', background: isDark ? '#243322' : '#0a4f2e' }}>
          {[
            { label: 'Earned this month', value: '840 pts' },
            { label: 'Redeemed total', value: '1,200 pts' },
            { label: 'Next expiry', value: 'Dec 31' },
          ].map(stat => (
            <div key={stat.label} style={{ padding: '12px 8px', textAlign: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#fff', marginBottom: 2 }}>{stat.value}</div>
              <div style={{ fontSize: 9.5, color: 'rgba(255,255,255,0.6)', lineHeight: 1.3 }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="scroll-row" style={{ padding: '0 20px 16px', gap: 8 }}>
        {(['overview', 'offers', 'challenges', 'history'] as const).map(tab => (
          <button key={tab}
            onClick={() => setActiveTab(tab)}
            style={{ flex: '0 0 auto', padding: '8px 16px', borderRadius: 20, background: activeTab === tab ? '#0a4f2e' : cardBg, color: activeTab === tab ? '#fff' : muted, fontSize: 12, fontWeight: 500, border: `1.5px solid ${activeTab === tab ? '#0a4f2e' : border}`, cursor: 'pointer', transition: 'all 0.15s', textTransform: 'capitalize' }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Overview tab */}
      {activeTab === 'overview' && (
        <div style={{ padding: '0 20px' }}>
          {/* Spin wheel promo */}
          <div style={{ borderRadius: 18, background: cardBg, padding: '16px', marginBottom: 16, textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: text, marginBottom: 4 }}>Daily Spin Wheel 🎡</div>
            <div style={{ fontSize: 12, color: muted, marginBottom: 16 }}>Spin once per day for bonus points & offers</div>

            {/* Wheel visual */}
            <div style={{ position: 'relative', width: 160, height: 160, margin: '0 auto 16px', cursor: 'pointer' }} onClick={handleSpin}>
              <div style={{
                width: 160, height: 160, borderRadius: '50%',
                background: 'conic-gradient(#0a4f2e 0deg 60deg, #c9991a 60deg 120deg, #7c3aed 120deg 180deg, #0a4f2e 180deg 240deg, #dc2626 240deg 300deg, #c2691c 300deg 360deg)',
                transform: `rotate(${spinAngle}deg)`,
                transition: spinning ? 'transform 3s cubic-bezier(0.2, 0, 0, 1)' : 'none',
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
              }}>
                {/* Wheel segments text */}
                {['50 pts', '10%', '25 pts', 'Free\nDel', '200', '100 pts'].map((prize, i) => (
                  <div key={i} style={{
                    position: 'absolute',
                    left: '50%',
                    top: '50%',
                    width: 50,
                    height: 14,
                    transform: `rotate(${i * 60 + 30}deg) translateX(30px) translateY(-50%)`,
                    transformOrigin: 'left center',
                    fontSize: 9,
                    fontWeight: 700,
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                  }}>
                    {prize}
                  </div>
                ))}
              </div>
              {/* Center button */}
              <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 44, height: 44, borderRadius: '50%', background: cardBg, border: '3px solid #0a4f2e', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#0a4f2e', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>
                {spinning ? '...' : 'SPIN'}
              </div>
              {/* Pointer */}
              <div style={{ position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)', fontSize: 18 }}>▼</div>
            </div>

            {spinResult ? (
              <div style={{ padding: '10px 20px', borderRadius: 12, background: '#e8f5ee', display: 'inline-flex', gap: 8, alignItems: 'center' }}>
                <span style={{ fontSize: 18 }}>🎉</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#0a4f2e' }}>You won: {spinResult}!</span>
              </div>
            ) : (
              <button onClick={handleSpin} disabled={spinning} style={{ padding: '10px 28px', borderRadius: 12, background: spinning ? '#e8e3d9' : '#0a4f2e', color: spinning ? muted : '#fff', fontSize: 13, fontWeight: 700, border: 'none', cursor: spinning ? 'not-allowed' : 'pointer' }}>
                {spinning ? 'Spinning…' : 'Spin Now!'}
              </button>
            )}
          </div>

          {/* Tier benefits */}
          <div style={{ borderRadius: 18, background: cardBg, padding: '16px', marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: text, marginBottom: 14 }}>Membership Tiers</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {TIERS.map((tier, i) => {
                const isCurrent = tier.name === 'Gold'
                return (
                  <div key={tier.name} style={{ borderRadius: 14, border: `1.5px solid ${isCurrent ? '#c9991a' : border}`, overflow: 'hidden', opacity: i > 1 ? 0.7 : 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', background: isCurrent ? '#fef9e7' : 'transparent' }}>
                      <span style={{ fontSize: 20 }}>{tier.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: text }}>{tier.name}</span>
                          {isCurrent && <span style={{ fontSize: 9, background: '#c9991a', color: '#fff', padding: '1px 6px', borderRadius: 4, fontWeight: 700 }}>CURRENT</span>}
                        </div>
                        <div style={{ fontSize: 10, color: muted }}>{tier.min.toLocaleString()} – {tier.max === Infinity ? '∞' : tier.max.toLocaleString()} pts</div>
                      </div>
                    </div>
                    <div style={{ padding: '0 14px 10px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {tier.perks.map(perk => (
                        <span key={perk} style={{ fontSize: 10, color: '#0a4f2e', background: '#e8f5ee', padding: '2px 8px', borderRadius: 20 }}>{perk}</span>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Scratch cards */}
          <div style={{ borderRadius: 18, background: cardBg, padding: '16px', marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: text, marginBottom: 12 }}>Scratch Cards 🎴</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              {[
                { scratched: false, label: 'Scratch Me!' },
                { scratched: true, label: '₹50 OFF', color: '#c9991a' },
                { scratched: false, label: 'Scratch Me!' },
              ].map((card, i) => (
                <div key={i} style={{ borderRadius: 14, height: 80, background: card.scratched ? '#e8f5ee' : 'linear-gradient(135deg, #c9991a, #f0c040)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
                  {card.scratched ? (
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 18 }}>🎉</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#0a4f2e' }}>{card.label}</div>
                    </div>
                  ) : (
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 22 }}>🪙</div>
                      <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.9)', fontWeight: 600, marginTop: 4 }}>{card.label}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Offers tab */}
      {activeTab === 'offers' && (
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {OFFERS.map(offer => (
            <div key={offer.id} style={{ borderRadius: 16, background: cardBg, overflow: 'hidden' }}>
              <div style={{ display: 'flex', gap: 0 }}>
                <div style={{ width: 6, background: offer.accent, flexShrink: 0 }} />
                <div style={{ flex: 1, padding: '14px 16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: text }}>{offer.title}</div>
                    <span style={{ fontSize: 10, color: muted }}>Exp: {offer.expiry}</span>
                  </div>
                  <div style={{ fontSize: 12, color: muted, marginBottom: 10 }}>{offer.sub}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ padding: '5px 12px', border: `1.5px dashed ${offer.accent}`, borderRadius: 8, fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, color: offer.accent, background: offer.color }}>
                      {offer.code}
                    </div>
                    <button onClick={() => navigate('cart')} style={{ padding: '6px 14px', borderRadius: 10, background: offer.accent, color: '#fff', fontSize: 11, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Use Now</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Challenges tab */}
      {activeTab === 'challenges' && (
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {CHALLENGES.map(c => {
            const pct = Math.min((c.progress / c.total) * 100, 100)
            const progressDisplay = typeof c.progress === 'number' && c.progress > 100 ? `₹${c.progress.toLocaleString()}` : c.progress
            const totalDisplay = typeof c.total === 'number' && c.total > 100 ? `₹${c.total.toLocaleString()}` : c.total
            return (
              <div key={c.id} style={{ borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
                <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 14, background: '#e8f5ee', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>{c.icon}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: text, marginBottom: 2 }}>{c.title}</div>
                    <div style={{ fontSize: 12, color: muted }}>{c.desc}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#c9991a' }}>{c.reward}</div>
                    <div style={{ fontSize: 10, color: muted }}>reward</div>
                  </div>
                </div>
                <div style={{ marginBottom: 6 }}>
                  <div style={{ height: 6, borderRadius: 3, background: border, overflow: 'hidden' }}>
                    <div className="progress-fill" style={{ height: '100%', width: `${pct}%`, borderRadius: 3, background: '#0a4f2e' }} />
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 11, color: muted }}>{progressDisplay} / {totalDisplay}</span>
                  <span style={{ fontSize: 11, color: '#0a4f2e', fontWeight: 600 }}>{Math.round(pct)}% complete</span>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* History tab */}
      {activeTab === 'history' && (
        <div style={{ padding: '0 20px' }}>
          <div style={{ borderRadius: 16, background: cardBg, overflow: 'hidden' }}>
            {HISTORY.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', borderBottom: i < HISTORY.length - 1 ? `1px solid ${border}` : 'none' }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: item.type === 'earn' ? '#e8f5ee' : item.type === 'bonus' ? '#fef9e7' : '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
                  {item.type === 'earn' ? '🛒' : item.type === 'bonus' ? '⭐' : '💳'}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 500, color: text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.desc}</div>
                  <div style={{ fontSize: 10, color: muted }}>{item.date}</div>
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: item.pts > 0 ? '#0a4f2e' : '#dc2626', fontFamily: 'var(--font-mono)' }}>
                    {item.pts > 0 ? '+' : ''}{item.pts} pts
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ height: 24 }} />
    </div>
  )
}
