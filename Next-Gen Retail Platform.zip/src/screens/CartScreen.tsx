import { useState } from 'react'
import Img from '../components/Img'
import type { CartItem, Product } from '../data/types'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  cart: CartItem[]
  updateCartQty: (id: number, qty: number) => void
  cartTotal: number
  isDark: boolean
  openProduct: (p: Product) => void
}

const DELIVERY_SLOTS = [
  { id: 1, time: 'Today, 2:00 – 4:00 PM', type: 'Express', price: 49, available: true },
  { id: 2, time: 'Today, 5:00 – 7:00 PM', type: 'Standard', price: 0, available: true },
  { id: 3, time: 'Today, 7:00 – 9:00 PM', type: 'Standard', price: 0, available: false },
  { id: 4, time: 'Tomorrow, 9:00 – 11:00 AM', type: 'Standard', price: 0, available: true },
]

const PROMOS = { FRESH10: 10, GOLD20: 20, WELCOME15: 15 }

export default function CartScreen({ navigate, cart, updateCartQty, cartTotal, isDark, openProduct }: Props) {
  const [selectedSlot, setSelectedSlot] = useState(2)
  const [promoCode, setPromoCode] = useState('')
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null)
  const [promoError, setPromoError] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('upi')
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart')
  const [tip, setTip] = useState(0)

  const bg = isDark ? '#0f1a13' : '#f7f6f2'
  const cardBg = isDark ? '#1a2b20' : '#ffffff'
  const text = isDark ? '#f0ede6' : '#14110e'
  const muted = isDark ? '#9a9480' : '#6b6455'
  const border = isDark ? '#243322' : '#e4e0d8'

  const deliveryFee = DELIVERY_SLOTS.find(s => s.id === selectedSlot)?.price || 0
  const discount = appliedPromo ? Math.round(cartTotal * (PROMOS[appliedPromo as keyof typeof PROMOS] / 100)) : 0
  const total = cartTotal + deliveryFee - discount + tip

  const applyPromo = () => {
    const code = promoCode.trim().toUpperCase()
    if (code in PROMOS) {
      setAppliedPromo(code)
      setPromoError('')
    } else {
      setPromoError('Invalid promo code')
      setAppliedPromo(null)
    }
  }

  if (checkoutStep === 'success') {
    return (
      <div style={{ background: bg, minHeight: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px', textAlign: 'center' }}>
        <div style={{ width: 80, height: 80, borderRadius: 24, background: '#e8f5ee', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, marginBottom: 20, animation: 'badgePop 0.5s ease' }}>
          ✅
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, color: text, marginBottom: 8 }}>Order Placed!</div>
        <div style={{ fontSize: 13, color: muted, marginBottom: 4 }}>Order #FM-2024-8471</div>
        <div style={{ fontSize: 13, color: muted, marginBottom: 28 }}>Estimated delivery: Today, 5:00 – 7:00 PM</div>
        <div style={{ width: '100%', padding: '16px', borderRadius: 16, background: cardBg, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: muted }}>Total paid</span>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#0a4f2e' }}>₹{total.toLocaleString()}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, color: muted }}>Points earned</span>
            <span style={{ fontSize: 13, color: '#c9991a', fontWeight: 600 }}>+{Math.floor(total * 0.05)} pts 🏆</span>
          </div>
        </div>
        <button onClick={() => navigate('orders')} style={{ width: '100%', padding: '14px', borderRadius: 14, background: '#0a4f2e', color: '#fff', fontSize: 14, fontWeight: 700, border: 'none', cursor: 'pointer', marginBottom: 12 }}>
          Track My Order
        </button>
        <button onClick={() => navigate('home')} style={{ width: '100%', padding: '14px', borderRadius: 14, background: 'transparent', color: '#0a4f2e', fontSize: 14, fontWeight: 600, border: `1.5px solid #0a4f2e`, cursor: 'pointer' }}>
          Continue Shopping
        </button>
      </div>
    )
  }

  if (cart.length === 0) {
    return (
      <div style={{ background: bg, minHeight: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px', textAlign: 'center' }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>🛒</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: text, marginBottom: 8 }}>Your cart is empty</div>
        <div style={{ fontSize: 13, color: muted, marginBottom: 28, maxWidth: 240 }}>
          Looks like you haven't added anything yet. Let's find something fresh!
        </div>
        <button onClick={() => navigate('shop')} style={{ padding: '14px 36px', borderRadius: 14, background: '#0a4f2e', color: '#fff', fontSize: 14, fontWeight: 700, border: 'none', cursor: 'pointer' }}>
          Start Shopping
        </button>
      </div>
    )
  }

  return (
    <div style={{ background: bg, minHeight: '100%' }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '0 20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: text }}>
          {checkoutStep === 'cart' ? 'My Cart' : 'Checkout'}
        </div>
        {checkoutStep === 'cart' && (
          <span style={{ fontSize: 12, color: muted }}>{cart.length} items</span>
        )}
        {checkoutStep === 'checkout' && (
          <button onClick={() => setCheckoutStep('cart')} style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>← Back</button>
        )}
      </div>

      {checkoutStep === 'cart' && (
        <>
          {/* Cart items */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '0 20px 16px' }}>
            {cart.map(({ product, qty }) => (
              <div key={product.id} style={{ borderRadius: 16, background: cardBg, padding: '12px', display: 'flex', gap: 12, alignItems: 'center' }} onClick={() => openProduct(product)}>
                <div style={{ width: 70, height: 70, borderRadius: 12, overflow: 'hidden', flexShrink: 0 }}>
                  <Img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 10, color: muted, marginBottom: 2 }}>{product.brand}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: text, lineHeight: 1.3, marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{product.name}</div>
                  <div style={{ fontSize: 11, color: muted, marginBottom: 6 }}>{product.unit}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 15, fontWeight: 700, color: '#0a4f2e' }}>₹{(product.price * qty).toLocaleString()}</span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 0, borderRadius: 10, border: `1.5px solid ${border}`, overflow: 'hidden' }} onClick={e => e.stopPropagation()}>
                      <button onClick={() => updateCartQty(product.id, qty - 1)} style={{ width: 32, height: 30, background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: qty === 1 ? '#dc2626' : text, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        {qty === 1 ? '🗑' : '−'}
                      </button>
                      <span style={{ width: 24, textAlign: 'center', fontSize: 13, fontWeight: 600, color: text }}>{qty}</span>
                      <button onClick={() => updateCartQty(product.id, qty + 1)} style={{ width: 32, height: 30, background: '#0a4f2e', border: 'none', fontSize: 18, cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Promo code */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: text, marginBottom: 10 }}>Promo Code</div>
            {appliedPromo ? (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', borderRadius: 12, background: '#e8f5ee', border: '1.5px solid #0a4f2e' }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#0a4f2e' }}>{appliedPromo} applied!</div>
                  <div style={{ fontSize: 11, color: '#0a4f2e' }}>−₹{discount} saved</div>
                </div>
                <button onClick={() => { setAppliedPromo(null); setPromoCode('') }} style={{ fontSize: 12, color: '#dc2626', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>Remove</button>
              </div>
            ) : (
              <>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input
                    value={promoCode}
                    onChange={e => setPromoCode(e.target.value)}
                    placeholder="Enter promo code"
                    style={{ flex: 1, padding: '10px 12px', borderRadius: 10, border: `1.5px solid ${border}`, background: bg, color: text, fontFamily: 'var(--font-body)', fontSize: 13, outline: 'none' }}
                  />
                  <button onClick={applyPromo} style={{ padding: '10px 16px', borderRadius: 10, background: '#0a4f2e', color: '#fff', fontSize: 12, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Apply</button>
                </div>
                {promoError && <div style={{ fontSize: 11, color: '#dc2626', marginTop: 6 }}>{promoError}</div>}
                <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                  {['FRESH10', 'GOLD20'].map(code => (
                    <button key={code} onClick={() => setPromoCode(code)} style={{ padding: '4px 10px', borderRadius: 20, border: '1.5px dashed #c9991a', color: '#c9991a', fontSize: 10, fontWeight: 600, background: 'none', cursor: 'pointer' }}>{code}</button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Delivery tip */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: text }}>Tip your delivery partner</div>
              <div style={{ fontSize: 11, color: muted }}>100% goes to them</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {[0, 10, 20, 30, 50].map(t => (
                <button key={t} onClick={() => setTip(t)}
                  style={{ flex: 1, padding: '8px 0', borderRadius: 10, background: tip === t ? '#0a4f2e' : bg, color: tip === t ? '#fff' : muted, fontSize: 11, fontWeight: 600, border: `1.5px solid ${tip === t ? '#0a4f2e' : border}`, cursor: 'pointer', transition: 'all 0.15s' }}
                >
                  {t === 0 ? 'None' : `₹${t}`}
                </button>
              ))}
            </div>
          </div>

          {/* Order summary */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: text, marginBottom: 12 }}>Order Summary</div>
            {[
              { label: `Subtotal (${cart.length} items)`, value: `₹${cartTotal.toLocaleString()}` },
              { label: 'Delivery fee', value: deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`, green: deliveryFee === 0 },
              ...(discount > 0 ? [{ label: `Promo (${appliedPromo})`, value: `-₹${discount}`, green: true }] : []),
              ...(tip > 0 ? [{ label: 'Delivery tip', value: `₹${tip}` }] : []),
            ].map(row => (
              <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 13, color: muted }}>{row.label}</span>
                <span style={{ fontSize: 13, fontWeight: 500, color: row.green ? '#0a4f2e' : text }}>{row.value}</span>
              </div>
            ))}
            <div style={{ height: 1, background: border, margin: '10px 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 15, fontWeight: 700, color: text }}>Total</span>
              <span style={{ fontSize: 18, fontWeight: 700, color: '#0a4f2e' }}>₹{total.toLocaleString()}</span>
            </div>
            <div style={{ fontSize: 11, color: '#c9991a', marginTop: 4, textAlign: 'right' }}>+{Math.floor(total * 0.05)} loyalty points</div>
          </div>

          {/* CTA */}
          <div style={{ padding: '0 20px 20px' }}>
            <button onClick={() => setCheckoutStep('checkout')} style={{ width: '100%', padding: '16px', borderRadius: 16, background: '#0a4f2e', color: '#fff', fontSize: 15, fontWeight: 700, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <span>Proceed to Checkout</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14 }}>₹{total.toLocaleString()}</span>
            </button>
          </div>
        </>
      )}

      {checkoutStep === 'checkout' && (
        <>
          {/* Delivery address */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: text }}>Delivery Address</div>
              <button onClick={() => alert('Address picker — add your saved addresses here')} style={{ fontSize: 12, color: '#0a4f2e', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>Change</button>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: '#e8f5ee', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>🏠</div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: text }}>Home</div>
                <div style={{ fontSize: 12, color: muted, lineHeight: 1.5 }}>42, 7th Cross, HSR Layout, Sector 3, Bangalore — 560102</div>
              </div>
            </div>
          </div>

          {/* Delivery slot */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: text, marginBottom: 10 }}>Delivery Slot</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {DELIVERY_SLOTS.map(slot => (
                <button key={slot.id}
                  onClick={() => slot.available && setSelectedSlot(slot.id)}
                  disabled={!slot.available}
                  style={{
                    padding: '10px 14px',
                    borderRadius: 12,
                    border: `1.5px solid ${selectedSlot === slot.id ? '#0a4f2e' : border}`,
                    background: selectedSlot === slot.id ? '#e8f5ee' : 'transparent',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    cursor: slot.available ? 'pointer' : 'not-allowed',
                    opacity: slot.available ? 1 : 0.5,
                  }}
                >
                  <div style={{ textAlign: 'left' }}>
                    <div style={{ fontSize: 12, fontWeight: 500, color: text }}>{slot.time}</div>
                    <div style={{ fontSize: 10, color: muted }}>{slot.type}{!slot.available ? ' · Full' : ''}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: slot.price === 0 ? '#0a4f2e' : text }}>{slot.price === 0 ? 'FREE' : `₹${slot.price}`}</div>
                    {selectedSlot === slot.id && <div style={{ fontSize: 10, color: '#0a4f2e' }}>Selected ✓</div>}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Payment */}
          <div style={{ margin: '0 20px 16px', borderRadius: 16, background: cardBg, padding: '14px 16px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: text, marginBottom: 10 }}>Payment Method</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { id: 'upi', label: 'UPI', sub: 'Google Pay, PhonePe, Paytm', icon: '📱' },
                { id: 'card', label: 'Credit / Debit Card', sub: 'Visa, Mastercard, Rupay', icon: '💳' },
                { id: 'wallet', label: 'FreshMart Wallet', sub: 'Balance: ₹340', icon: '👛' },
                { id: 'cod', label: 'Cash on Delivery', sub: 'Pay at door', icon: '💵' },
              ].map(method => (
                <button key={method.id}
                  onClick={() => setPaymentMethod(method.id)}
                  style={{ padding: '10px 14px', borderRadius: 12, border: `1.5px solid ${paymentMethod === method.id ? '#0a4f2e' : border}`, background: paymentMethod === method.id ? '#e8f5ee' : 'transparent', display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer', textAlign: 'left' }}
                >
                  <span style={{ fontSize: 20 }}>{method.icon}</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: text }}>{method.label}</div>
                    <div style={{ fontSize: 10.5, color: muted }}>{method.sub}</div>
                  </div>
                  {paymentMethod === method.id && <span style={{ marginLeft: 'auto', fontSize: 14, color: '#0a4f2e' }}>✓</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Final total + Pay */}
          <div style={{ padding: '0 20px 20px' }}>
            <div style={{ borderRadius: 16, background: '#0a4f2e', padding: '16px', marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>Total payable</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: '#fff' }}>₹{total.toLocaleString()}</span>
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>+{Math.floor(total * 0.05)} Gold points · Delivers {DELIVERY_SLOTS.find(s => s.id === selectedSlot)?.time}</div>
            </div>
            <button onClick={() => setCheckoutStep('success')} style={{ width: '100%', padding: '16px', borderRadius: 16, background: '#c9991a', color: '#fff', fontSize: 15, fontWeight: 700, border: 'none', cursor: 'pointer' }}>
              Place Order · {paymentMethod === 'cod' ? 'Cash on Delivery' : `Pay ₹${total.toLocaleString()}`}
            </button>
          </div>
        </>
      )}
    </div>
  )
}
