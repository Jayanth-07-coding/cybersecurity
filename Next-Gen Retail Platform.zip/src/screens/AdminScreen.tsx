import { useState } from 'react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts'
import type { Screen } from '../App'

interface Props {
  navigate: (s: Screen) => void
  isDark: boolean
  setIsDark: (v: boolean) => void
}

const REVENUE_DATA = [
  { day: 'Mon', revenue: 84200, orders: 312 },
  { day: 'Tue', revenue: 92100, orders: 341 },
  { day: 'Wed', revenue: 78400, orders: 289 },
  { day: 'Thu', revenue: 110300, orders: 408 },
  { day: 'Fri', revenue: 134600, orders: 521 },
  { day: 'Sat', revenue: 189200, orders: 724 },
  { day: 'Sun', revenue: 156800, orders: 612 },
]

const CATEGORY_DATA = [
  { name: 'Fresh Produce', value: 32, color: '#0a4f2e' },
  { name: 'Dairy & Eggs', value: 22, color: '#c9991a' },
  { name: 'Beverages', value: 18, color: '#3b82f6' },
  { name: 'Bakery', value: 12, color: '#c2691c' },
  { name: 'Snacks', value: 10, color: '#7c3aed' },
  { name: 'Other', value: 6, color: '#94a3b8' },
]

const HOURLY_DATA = [
  { h: '8 AM', sales: 4200 }, { h: '9 AM', sales: 8100 }, { h: '10 AM', sales: 12400 },
  { h: '11 AM', sales: 9800 }, { h: '12 PM', sales: 15200 }, { h: '1 PM', sales: 13600 },
  { h: '2 PM', sales: 11200 }, { h: '3 PM', sales: 9400 }, { h: '4 PM', sales: 14800 },
  { h: '5 PM', sales: 19200 }, { h: '6 PM', sales: 22400 }, { h: '7 PM', sales: 18900 },
  { h: '8 PM', sales: 14200 }, { h: '9 PM', sales: 8400 },
]

const TOP_PRODUCTS = [
  { name: 'Organic Alphonso Mangoes', sold: 847, revenue: 253253, stock: 48, trend: 'up' },
  { name: 'Artisan Sourdough Bread', sold: 634, revenue: 126166, stock: 22, trend: 'up' },
  { name: 'Norwegian Salmon Fillet', sold: 289, revenue: 259711, stock: 15, trend: 'stable' },
  { name: 'Greek Yogurt Natural', sold: 1203, revenue: 102255, stock: 89, trend: 'up' },
  { name: 'Premium Matcha Powder', sold: 156, revenue: 85644, stock: 8, trend: 'down' },
]

const RECENT_ORDERS = [
  { id: '#8481', customer: 'Kavya Menon', amount: 1240, status: 'delivered', time: '2 min ago', items: 5 },
  { id: '#8480', customer: 'Arjun Patel', amount: 890, status: 'processing', time: '8 min ago', items: 3 },
  { id: '#8479', customer: 'Sneha Iyer', amount: 2340, status: 'out_for_delivery', time: '15 min ago', items: 8 },
  { id: '#8478', customer: 'Rohit Sharma', amount: 445, status: 'delivered', time: '23 min ago', items: 2 },
  { id: '#8477', customer: 'Meera Nair', amount: 1890, status: 'delivered', time: '41 min ago', items: 7 },
]

const LOW_STOCK = [
  { name: 'Norwegian Salmon Fillet', stock: 8, threshold: 20, category: 'Meat & Seafood' },
  { name: 'Premium Matcha Powder', stock: 5, threshold: 15, category: 'Beverages' },
  { name: 'Burrata Cheese', stock: 3, threshold: 10, category: 'Dairy' },
  { name: 'Artisan Sourdough Bread', stock: 12, threshold: 30, category: 'Bakery' },
]

const NAV_ITEMS = [
  { id: 'overview', icon: '📊', label: 'Overview' },
  { id: 'orders', icon: '📦', label: 'Orders' },
  { id: 'products', icon: '🛒', label: 'Products' },
  { id: 'customers', icon: '👥', label: 'Customers' },
  { id: 'analytics', icon: '📈', label: 'Analytics' },
]

export default function AdminScreen({ navigate, isDark, setIsDark }: Props) {
  const [activeNav, setActiveNav] = useState('overview')
  const [dateRange, setDateRange] = useState('7d')

  const bg = '#0f1a13'
  const panel = '#1a2b20'
  const panel2 = '#162318'
  const text = '#e8f5ee'
  const muted = '#6a9a7a'
  const border = '#243322'
  const accent = '#22c55e'

  const totalRevenue = REVENUE_DATA.reduce((s, d) => s + d.revenue, 0)
  const totalOrders = REVENUE_DATA.reduce((s, d) => s + d.orders, 0)

  const customTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null
    return (
      <div style={{ background: panel, border: `1px solid ${border}`, borderRadius: 8, padding: '8px 12px', fontSize: 11 }}>
        <div style={{ color: muted, marginBottom: 4 }}>{label}</div>
        {payload.map((p: any) => (
          <div key={p.key} style={{ color: text, fontWeight: 600 }}>
            {p.name === 'revenue' ? `₹${(p.value/1000).toFixed(1)}k` : p.value} {p.name}
          </div>
        ))}
      </div>
    )
  }

  return (
    <div style={{ background: bg, minHeight: '100%', display: 'grid', gridTemplateColumns: '56px 1fr', height: '100%' }}>
      {/* Sidebar */}
      <div style={{ background: panel2, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 56, paddingBottom: 16, gap: 4, borderRight: `1px solid ${border}` }}>
        <div style={{ fontSize: 18, marginBottom: 16 }}>🌿</div>
        {NAV_ITEMS.map(item => (
          <button key={item.id}
            onClick={() => setActiveNav(item.id)}
            title={item.label}
            style={{ width: 40, height: 40, borderRadius: 12, background: activeNav === item.id ? '#243322' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, border: 'none', cursor: 'pointer', transition: 'background 0.15s' }}
          >
            {item.icon}
          </button>
        ))}
        <div style={{ flex: 1 }} />
        <button onClick={() => navigate('home')} title="Back to app" style={{ width: 40, height: 40, borderRadius: 12, background: 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, border: 'none', cursor: 'pointer' }}>
          📱
        </button>
      </div>

      {/* Main content */}
      <div style={{ overflow: 'auto', padding: '48px 16px 20px' }}>

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: text }}>
              {NAV_ITEMS.find(n => n.id === activeNav)?.label || 'Overview'}
            </div>
            <div style={{ fontSize: 11, color: muted, marginTop: 1 }}>Today: Jul 24, 2024</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['1d', '7d', '30d'].map(d => (
              <button key={d} onClick={() => setDateRange(d)}
                style={{ padding: '5px 10px', borderRadius: 8, background: dateRange === d ? accent : 'transparent', color: dateRange === d ? '#0a1a0e' : muted, fontSize: 10, fontWeight: 600, border: `1px solid ${dateRange === d ? accent : border}`, cursor: 'pointer' }}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          {[
            { label: 'Revenue', value: `₹${(totalRevenue / 100000).toFixed(2)}L`, change: '+18.4%', up: true, icon: '💰' },
            { label: 'Orders', value: totalOrders.toLocaleString(), change: '+12.1%', up: true, icon: '📦' },
            { label: 'Avg Order', value: `₹${Math.round(totalRevenue / totalOrders)}`, change: '+5.7%', up: true, icon: '🛒' },
            { label: 'Active Users', value: '2,847', change: '+8.3%', up: true, icon: '👥' },
          ].map(kpi => (
            <div key={kpi.label} style={{ borderRadius: 14, background: panel, padding: '12px 14px', border: `1px solid ${border}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <span style={{ fontSize: 16 }}>{kpi.icon}</span>
                <span style={{ fontSize: 10, fontWeight: 700, color: kpi.up ? '#22c55e' : '#ef4444', background: kpi.up ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)', padding: '2px 6px', borderRadius: 6 }}>
                  {kpi.change}
                </span>
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: text, marginBottom: 2 }}>{kpi.value}</div>
              <div style={{ fontSize: 10.5, color: muted }}>{kpi.label} this week</div>
            </div>
          ))}
        </div>

        {/* Revenue chart */}
        <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}`, marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: text }}>Revenue & Orders</div>
            <div style={{ fontSize: 10, color: muted }}>7-day trend</div>
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <AreaChart data={REVENUE_DATA} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={border} />
              <XAxis dataKey="day" tick={{ fontSize: 9, fill: muted }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: muted }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
              <Tooltip content={customTooltip} />
              <Area type="monotone" dataKey="revenue" name="revenue" stroke="#22c55e" strokeWidth={2} fill="url(#revGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Hourly heatmap bar */}
        <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}`, marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: text, marginBottom: 12 }}>Today's Hourly Sales</div>
          <ResponsiveContainer width="100%" height={80}>
            <BarChart data={HOURLY_DATA} margin={{ top: 0, right: 0, bottom: 0, left: -28 }}>
              <XAxis dataKey="h" tick={{ fontSize: 8, fill: muted }} axisLine={false} tickLine={false} />
              <Tooltip content={customTooltip} />
              <Bar dataKey="sales" name="sales" radius={[3, 3, 0, 0]}>
                {HOURLY_DATA.map((_, i) => (
                  <Cell key={i} fill={i === 10 || i === 11 ? '#22c55e' : '#243322'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Category split + Low stock */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          {/* Category pie */}
          <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}` }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: text, marginBottom: 8 }}>Category Split</div>
            <ResponsiveContainer width="100%" height={80}>
              <PieChart>
                <Pie data={CATEGORY_DATA} cx="50%" cy="50%" innerRadius={22} outerRadius={38} dataKey="value" strokeWidth={0}>
                  {CATEGORY_DATA.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(v) => `${v}%`} contentStyle={{ background: panel, border: `1px solid ${border}`, borderRadius: 8, fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 3, marginTop: 4 }}>
              {CATEGORY_DATA.slice(0, 3).map(c => (
                <div key={c.name} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <div style={{ width: 6, height: 6, borderRadius: 2, background: c.color }} />
                  <span style={{ fontSize: 9, color: muted, flex: 1 }}>{c.name}</span>
                  <span style={{ fontSize: 9, fontWeight: 600, color: text }}>{c.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Low stock */}
          <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: text }}>Low Stock</div>
              <span style={{ fontSize: 9, background: 'rgba(239,68,68,0.15)', color: '#ef4444', padding: '2px 6px', borderRadius: 4, fontWeight: 700 }}>
                {LOW_STOCK.length} items
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {LOW_STOCK.map(item => (
                <div key={item.name}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                    <span style={{ fontSize: 9.5, color: text, display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden', maxWidth: '75%' }}>{item.name}</span>
                    <span style={{ fontSize: 9.5, color: item.stock < 10 ? '#ef4444' : '#f59e0b', fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{item.stock}</span>
                  </div>
                  <div style={{ height: 3, borderRadius: 2, background: border }}>
                    <div style={{ height: '100%', width: `${(item.stock / item.threshold) * 100}%`, borderRadius: 2, background: item.stock < 10 ? '#ef4444' : '#f59e0b' }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top products */}
        <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}`, marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: text }}>Top Products</div>
            <span style={{ fontSize: 10, color: accent }}>View all →</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {TOP_PRODUCTS.map((p, i) => (
              <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0', borderBottom: i < TOP_PRODUCTS.length - 1 ? `1px solid ${border}` : 'none' }}>
                <span style={{ fontSize: 10, color: muted, width: 12, fontFamily: 'var(--font-mono)' }}>{i + 1}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 10.5, color: text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                  <div style={{ fontSize: 9, color: muted }}>{p.sold} sold · {p.stock} left</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 10.5, fontWeight: 700, color: text, fontFamily: 'var(--font-mono)' }}>₹{(p.revenue / 1000).toFixed(1)}k</div>
                  <div style={{ fontSize: 9, color: p.trend === 'up' ? '#22c55e' : p.trend === 'down' ? '#ef4444' : muted }}>
                    {p.trend === 'up' ? '↑' : p.trend === 'down' ? '↓' : '→'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent orders */}
        <div style={{ borderRadius: 14, background: panel, padding: '14px', border: `1px solid ${border}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: text }}>Recent Orders</div>
            <span style={{ fontSize: 10, color: accent }}>View all →</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {RECENT_ORDERS.map((order, i) => {
              const statusColors: Record<string, string> = {
                delivered: '#22c55e',
                processing: '#3b82f6',
                out_for_delivery: '#f59e0b',
              }
              return (
                <div key={order.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: i < RECENT_ORDERS.length - 1 ? `1px solid ${border}` : 'none' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                      <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: accent }}>{order.id}</span>
                      <span style={{ fontSize: 9, color: muted }}>· {order.time}</span>
                    </div>
                    <div style={{ fontSize: 10, color: muted }}>{order.customer} · {order.items} items</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: text }}>₹{order.amount.toLocaleString()}</div>
                    <div style={{ fontSize: 9, color: statusColors[order.status] || muted, fontWeight: 500, textTransform: 'capitalize' }}>
                      {order.status.replace('_', ' ')}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Alert bar */}
        <div style={{ marginTop: 14, borderRadius: 12, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)', padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 16 }}>⚠️</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#ef4444' }}>3 products critically low on stock</div>
            <div style={{ fontSize: 10, color: muted }}>Burrata Cheese: 3 units, Matcha Powder: 5 units</div>
          </div>
          <button style={{ padding: '6px 12px', borderRadius: 8, background: '#ef4444', color: '#fff', fontSize: 10, fontWeight: 700, border: 'none', cursor: 'pointer' }}>Restock</button>
        </div>

        <div style={{ height: 16 }} />
      </div>
    </div>
  )
}
